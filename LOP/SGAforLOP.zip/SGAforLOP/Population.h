//
//  Population.h
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#ifndef _POPULATION_
#define _POPULATION_

#include <vector>
#include <algorithm>
#include <string.h>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include "Individual.h"
#include "QAP.h"

using std::istream;
using std::ostream;
using std::stringstream;
using std::string;
using namespace std;
class CPopulation;


class CPopulation
{
    
public:
    
    struct Better{
        bool operator()(CIndividual * a, CIndividual * b) const{
                return a->m_value>b->m_value;
        }
    } Better;
    
    /*
     * Vector of individuals that constitute the population.
     */
    vector<CIndividual *> m_individuals;

    vector< vector<int> > m_S;
    vector< vector<int> > m_F;
    vector<CIndividual *> m_clone;
    int * m_n;
    int * m_marks;
    
    /*
     * Size of the population
     */
    int m_pop_size;
    
    /*
     * Size of the individuals
     */
    int m_problem_size;
    
	/*
     * The constructor. It creates an empty list.
     */
    CPopulation(int pop_size, int individual_size);
    
	/*
     * The destructor.
     */
	virtual ~CPopulation();
    

    /*
     * Function to set an individual in a specific position of the population
     */
    void SetToPopulation(int * genes, int index, int fitness, double * fc);
    
    /*
     * Sorts the individuals in the population in ascending order of the fitness value.
     * returns true if the best solution was outperformed.
     */
    bool SortPopulation(CIndividual * best);
    
    /*
     *  Performs the nondominated sorting of the NSGA-II proposed by debt et al.
     */
    bool Fast_NonDominatedSorting(CIndividual * best);
   
    /*
     * Checks whether there exists a solution in the population with the given fitness.
     */
    bool Exists(int i, int fitness);
    
    /*
     * Prints the current population.
     */
    void Print(int samples);
    
	/*
	 * Determines if the individuals in the population are equal.
	 */
	bool Same(int size);
    
    /*
     * Calculates the average fitness of the first 'size' solutions in the population
     */
    float AverageFitnessPopulation(int size);
    
    /*
     * Returns the best individual of the population.
     */
    CIndividual * BestIndividual();
    
    /*
     * Calculates the average distance of the first 'size' solutions in the population
     */
    float AverageDistancePopulation(int size);
    
	
private:
    
};

#endif


