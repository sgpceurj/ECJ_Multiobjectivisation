//
//  Individual.cc
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#include "Individual.h"
#include "Tools.h"

// The object storing the values of all the individuals
// that have been created during the execution of the
// program. 

CIndividual::CIndividual(int length)
{
	m_size = length;
	m_genes = new int[m_size];
    m_value=MIN_LONG_INTEGER;
    m_fc= new double[3];
    m_fc[0]=MIN_LONG_INTEGER;
    m_fc[1]=MIN_LONG_INTEGER;
    m_fc[2]=MIN_LONG_INTEGER;
}

/*
 * The descructor of the class individual
 */
CIndividual::~CIndividual()
{
	delete [] m_genes;
    delete [] m_fc;
	m_genes=NULL;
}

/*
 * Output operator.
 */
ostream & operator<<(ostream & os,CIndividual * & individual)
{
    os << individual->m_genes[0];
	for(int i=1;i<individual->m_size;i++)
        os << " " << individual->m_genes[i];
	return os;
}

/*
 * Input operator.
 */
istream & operator>>(istream & is,CIndividual * & individual)
{
  char k; //to avoid intermediate characters such as ,.

  is >> individual->m_value;
  is >> individual->m_genes[0];
  for(int i=1;i<individual->m_size;i++)
    is >> k >> individual->m_genes[i];
  is >> k;

  return is;
}


/*
 * Prints in the standard output genes.
 */
void CIndividual::PrintGenes()
{
	for (int i=0;i<m_size;i++){
		cout<<m_genes[i]<<" ";
	}
	cout<<" "<<endl;
}


