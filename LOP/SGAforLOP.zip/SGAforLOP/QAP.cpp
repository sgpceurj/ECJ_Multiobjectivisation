/*
 *  QAP.cpp
 *  RankingEDAsCEC
 *
 *  Created by Josu Ceberio Uribe on 7/11/13.
 *  Copyright 2013 University of the Basque Country. All rights reserved.
 *
 */

#include "QAP.h"
#include "Variables.h"

/*
 *Class constructor.
 */
QAP::QAP()
{

}

/*
 * Class destructor.
 */
QAP::~QAP()
{
	for (int i=0;i<m_size;i++)
	{
		delete [] m_distance_matrix[i];
		delete [] m_flow_matrix[i];
	}
	delete [] m_flow_matrix;
	delete [] m_distance_matrix;

}

int QAP::ReadLOPInstanceAsQAP(string filename)
{
    char line[2048]; // variable for input value
    string data="";
    ifstream indata;
    indata.open(filename.c_str(),ios::in);
    int num=0;
    int i,j;
    while (!indata.eof())
    {
    //LEER LA LINEA DEL FICHERO
    indata.getline(line, 2048);
    stringstream ss;
    string sline;
    ss << line;
    ss >> sline;
    if (sline=="")
    {
        break;
    }
    if (num==0)
    {
        //primera linea
        m_size = atoi(line);
        //cout << "Problem size: "<< line<<endl;
    }
    else
    {
        if (data=="")
            data = line;
            else
                data = data+' '+line;
                }
    num++;
    }
    indata.close();
    
    m_flow_matrix = new int*[m_size];
    m_distance_matrix=new int*[m_size];
    for (int i=0;i<m_size;i++)
    {
        m_flow_matrix[i]= new int[m_size];
        m_distance_matrix[i]=new int[m_size];
        for (j=0;j<=i;j++)
            m_distance_matrix[i][j]=0;
        for (j=i+1;j<m_size;j++)
            m_distance_matrix[i][j]=1;
    
    }

    istringstream iss(data);
    i=0;
    j=0;
    do
    {
    string sub;
    iss >> sub;
    if (sub!=""){
        //save values in the flow matrix
        m_flow_matrix[i][j]= atoi(sub.c_str());
        if (j==(m_size-1))
        {
            i++;
            j=0;
        }
        else
        {
            j++;
        }
    }
    else
    {
        break;
    }
    } while (iss);

    //PrintMatrix(m_flow_matrix, m_size, m_size, "Flow: ");
    //PrintMatrix(m_distance_matrix, m_size, m_size, "Distance: ");
    CalculateAverageComponents_ELD();

    return (m_size);
}
/*
 * This function evaluates the individuals for the QAP problem.
 */
double QAP::Evaluate(int * genes)
{
	double fitness=0;
	int FactA, FactB;
	int distAB, flowAB, i ,j;
	for (i=0;i<m_size;i++)
	{
		for (j=0;j<m_size;j++)
		{
			FactA = genes[i];
			FactB = genes[j];
			
			distAB= m_distance_matrix[i][j];
			flowAB= m_flow_matrix[FactA][FactB];
			fitness= fitness+(distAB*flowAB);			
		}
	}
    return fitness;
}

/*
 * This function evaluates the individuals for the QAP problem as LOP.
 */
double QAP::EvaluateAsLOP(int * genes)
{
    double fitness=0;
    int i,j;
    for (i=0;i<m_size-1;i++)
    {
        for (j=i+1;j<m_size;j++){
            fitness+= m_flow_matrix[genes[i]][genes[j]];
        }
    }
    return fitness;
}

/*
 * Returns the size of the problem.
 */
int QAP::GetProblemSize()
{
    return m_size;
}

/*
 * Omega 1.
 */
inline int Omega1(int i, int j, int p, int q, int * x, int n){
    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
        return -1; //rho
    if ((x[i]==p)^(x[j]==q))
        return -2; //gamma
    if ((x[i]==q)^(x[j]==p))
        return 0; //epsilon
    if ((x[i]==p)&&(x[j]==q))
        return n-3; //alpha.
    if ((x[i]==q)&&(x[j]==p))
        return 1-n; //beta
    cout<<"Error in Omega 1. "<<endl; exit(1);
}

/*
 * Omega 2.
 */
inline int Omega2(int i, int j, int p, int q, int * x, int n){
    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
        return 1; //rho
    if ((x[i]==p)^(x[j]==q))
        return 0; //gamma
    if ((x[i]==q)^(x[j]==p))
        return 0; //epsilon
    if ((x[i]==p)&&(x[j]==q))
        return n-3; //alpha.
    if ((x[i]==q)&&(x[j]==p))
        return n-3; //beta
    cout<<"Error in Omega 2. "<<endl; exit(1);
}

/*
 * Omega 2.
 */
inline int Omega3(int i, int j, int p, int q, int * x, int n){
    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
        return -1; //rho
    if ((x[i]==p)^(x[j]==q))
        return n-2; //gamma
    if ((x[i]==q)^(x[j]==p))
        return 0; //epsilon
    if ((x[i]==p)&&(x[j]==q))
        return 2*n-3; //alpha.
    if ((x[i]==q)&&(x[j]==p))
        return 1; //beta
    cout<<"Error in Omega 3. "<<endl; exit(1);
}

/*
 * Calculates the fitness value corresponding to the first component of the elementary landscape decomposition.
 */
double QAP::fc1_basic(int * genes){
    int i,j,p,q;
    double result=0;
    for (i=0;i<m_size;i++){
        for (j=0;j<m_size;j++){
            for (p=0;p<m_size;p++){
                for (q=0;q<m_size;q++){
                    if (i!=j && p!=q)
                        result+=(double)(Omega1(i,j,p,q, genes,m_size)*m_distance_matrix[i][j]*m_flow_matrix[p][q]);
                }
            }
        }
    }
    result=result/(double)(2*m_size);
    return result;
}
/*
 * Calculates the fitness value corresponding to the second component of the elementary landscape decomposition.
 */
double QAP::fc2_basic(int * genes){
    int i,j,p,q;
    double result=0;
    for (i=0;i<m_size;i++){
        for (j=0;j<m_size;j++){
            for (p=0;p<m_size;p++){
                for (q=0;q<m_size;q++){
                    if (i!=j && p!=q)
                        result+=(double)(Omega2(i,j,p,q, genes,m_size)*m_distance_matrix[i][j]*m_flow_matrix[p][q]);
                }
            }
        }
    }
    result=result/(double)(2*(m_size-2));
    return result;
}
/*
 * Calculates the fitness value corresponding to the third component of the elementary landscape decomposition.
 */
double QAP::fc3_basic(int * genes){
    int i,j,p,q;
    double result=0;
    for (i=0;i<m_size;i++){
        for (j=0;j<m_size;j++){
            for (p=0;p<m_size;p++){
                for (q=0;q<m_size;q++){
                    if (i!=j && p!=q)
                        result+=(double)(Omega3(i,j,p,q, genes,m_size)*m_distance_matrix[i][j]*m_flow_matrix[p][q]);
                }
            }
        }
    }
    result=result/(double)(m_size*(m_size-2));
    return result;
}


/*
 * Calculates the fitness value corresponding to the first component of the elementary landscape decomposition.
 */
double QAP::fc1(int * x){
    int i,j,p,q;
    double result=0;
    double psi;
    int n=m_size;
    for (i=0;i<m_size;i++){
        for (j=i+1;j<m_size;j++){ //lower triangle of distance matrix is 0, and upper triangle 1.
            for (p=0;p<m_size;p++){
                for (q=0;q<p;q++){
                    psi=m_flow_matrix[p][q];
                    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
                        result+= -psi; //rho
                    else if ((x[i]==p)^(x[j]==q))
                        result+= -2*psi; //gamma
                    //else if ((x[i]==q)^(x[j]==p))
                    //    result+= 0*psi; //epsilon
                    else if ((x[i]==p)&&(x[j]==q))
                        result+= (n-3)*psi; //alpha.
                    else if ((x[i]==q)&&(x[j]==p))
                        result+= (1-n)*psi; //beta
                }
                for (q=p+1;q<n;q++){
                    psi=m_flow_matrix[p][q];
                    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
                        result+= -psi; //rho
                    else if ((x[i]==p)^(x[j]==q))
                        result+= -2*psi; //gamma
                    //else if ((x[i]==q)^(x[j]==p))
                    //    result+= 0*psi; //epsilon
                    else if ((x[i]==p)&&(x[j]==q))
                        result+= (n-3)*psi; //alpha.
                    else if ((x[i]==q)&&(x[j]==p))
                        result+= (1-n)*psi; //beta
                }
            }
        }
    }
    result=result/(double)(2*m_size);
    return result;
}

/*
 * Calculates the fitness value decomposed in the three components of the elementary landscape decomposition.
 */
void QAP::f_components(int * x, double * components){
    int i,j,p,q;
    double psi;
    double result1=0, result2=0, result3=0;
    int n=m_size;
    for (i=0;i<n;i++){
        for (j=0;j<i;j++){
            for (p=0;p<n;p++){
                for (q=0;q<p;q++){
                    psi=m_distance_matrix[i][j]*m_flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                    //    result2+=(0)*psi; //gamma Omega2
                        result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=(n-3)*psi; //alpha Omega1
                        result2+=(n-3)*psi; //alpha Omega2
                        result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=(n-3)*psi; //beta Omega2
                        result3+= psi; //beta Omega3
                    }
                }
                for (q=p+1;q<n;q++){
                    psi=m_distance_matrix[i][j]*m_flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=(n-3)*psi; //alpha Omega1
                        result2+=(n-3)*psi; //alpha Omega2
                        result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=(n-3)*psi; //beta Omega2
                        result3+= psi; //beta Omega3
                    }

                }
            }
        }
        for (j=i+1;j<n;j++){
            for (p=0;p<n;p++){
                for (q=0;q<p;q++){
                    psi=m_distance_matrix[i][j]*m_flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=(n-3)*psi; //alpha Omega1
                        result2+=(n-3)*psi; //alpha Omega2
                        result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=(n-3)*psi; //beta Omega2
                        result3+= psi; //beta Omega3
                    }
                }
                for (q=p+1;q<n;q++){
                    psi=m_distance_matrix[i][j]*m_flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=(n-3)*psi; //alpha Omega1
                        result2+=(n-3)*psi; //alpha Omega2
                        result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=(n-3)*psi; //beta Omega2
                        result3+= psi; //beta Omega3
                    }
                    
                }
            }
        }
    }
    components[0]=result1/(double)(2*n);
    components[1]=result2/(double)(2*(n-2));
    components[2]=result3/(double)(n*(n-2));
}

/*
 * Calculates the average fitness components of the elementary landscape decomposition needed to calculate the average
 * fitness of a neighborhood in close form.
 */
void QAP::CalculateAverageComponents_ELD(){
    double phi=0;
    int i,j,p,q;
    for (i=0;i<m_size;i++){
        for (j=0;j<m_size;j++){
            for (p=0;p<m_size;p++){
                for (q=0;q<m_size;q++){
                    if (i!=j && p!=q)
                        phi+=m_distance_matrix[i][j]*m_flow_matrix[p][q];
                }
            }
        }
    }
    fc1_avg= - phi/(2*m_size);
    fc2_avg= phi * (m_size-3)/(2*(m_size-2)*(m_size-1));
    fc3_avg= phi/(m_size*(m_size-2));
    
    m_totalpq=0;
    for (p=0;p<m_size;p++){
        for (q=0;q<p;q++)
            m_totalpq += m_flow_matrix[p][q];
        for (q=p+1;q<m_size;q++)
            m_totalpq += m_flow_matrix[p][q];
    }
}

