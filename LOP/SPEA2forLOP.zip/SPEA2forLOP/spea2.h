/*========================================================================
  PISA  (www.tik.ee.ethz.ch/pisa/)
  ========================================================================
  Computer Engineering (TIK)
  ETH Zurich
  ========================================================================
  SPEA2 - Strength Pareto EA 2

  Implementation in C for the selector side.
  
  Header file.
  
  file: spea2.h
  author: Marco Laumanns, laumanns@tik.ee.ethz.ch

  revision by: Stefan Bleuler, bleuler@tik.ee.ethz.ch
  last change: $date$
  ========================================================================
*/

#ifndef SPEA2_H
#define SPEA2_H
//#define VERBOSE
//#define DIVERSITY_DATA
/*-----------------------| specify Operating System |------------------*/
/* necessary for wait() */

/* #define PISA_WIN */
#define PISA_UNIX

/*----------------------------| macro |----------------------------------*/

#define PISA_ERROR(x) fprintf(stderr, "\nError: " x "\n"), fflush(stderr), exit(EXIT_FAILURE)

/*---------------------------| constants |-------------------------------*/
#define FILE_NAME_LENGTH 128 /* maximal length of filenames */
#define CFG_ENTRY_LENGTH 128 /* maximal length of entries in cfg file */
#define PISA_MAXDOUBLE 1E99  /* Internal maximal value for double */
#define PISA_MINDOUBLE 1E-99  /* Internal minimal value for double */
#define MAX_INTEGER 2147483647 //Integer maximum value

/*----------------------------| structs |--------------------------------*/
#include <stdlib.h>
#include <stdio.h>
#include <vector>
typedef struct ind_st  /* an individual */
{
    int index;
    int * genes;
    int size;
    double *f; /* objective vector. En nuestro caso, tendrá dos objetivos. */
    double fitness; /* la fitness que le asigna el proceso */
    double real_fitness; /* la fitness real del problema. Nosotros podemos evaluarla */
} ind;

typedef struct pop_st  /* a population */
{
    int size;
    int maxsize;
    ind **ind_array;
} pop;

typedef struct qap_st
{
    int ** distance_matrix; /* The matrix of distances between the cities */
    int ** flow_matrix; /* The flow matrix between the cities. */
    int size; /* The size of the instance.*/
    double * fc_avg; /* average components of the elementary landscape decomposition */
    long int totalpq; /* auxiliary value for the computation of elementary landscape components */
    
    long int evaluations; /* number of evaluations performed */
    ind * best;
                     
}qap;

/*-------------| functions for control flow (in spea2.c) |------------*/

void write_flag(char *filename, int flag);
int read_flag(char *filename);
void waitt(double sec);

/*---------| initialization function (in spea2_functions.c) |---------*/

void initialize(qap * problem);

/*--------| memory allocation functions (in spea2_functions.c) |------*/

void* chk_malloc(size_t size);
pop* create_pop(int size, int dim);
ind* create_ind(int size,int dim);

void free_memory(void);
void free_pop(pop *pp);
void complete_free_pop(pop *pp);
void free_ind(ind *p_ind);

/*-----| functions implementing the selection (spea2_functions.c) |---*/

void selection();
void mergeOffspring();
void calcFitnesses();
void calcDistances();
int getNN(int index, int k);
double getNNd(int index, int k);
void environmentalSelection();
void truncate_nondominated();
void truncate_dominated();
void matingSelection();

void select_initial();
void select_normal();
int dominates(ind *p_ind_a, ind *p_ind_b);
int is_equal(ind *p_ind_a, ind *p_ind_b);
double calcDistance(ind *p_ind_a, ind *p_ind_b);
int irand(int range);

/*--------------------| data exchange functions |------------------------*/

/* in spea2_functions.c */

int read_ini(int ind_size);
int read_var(int ind_size);
void write_sel(void);
void write_arc(void);
int check_sel(void);
int check_arc(void);

/* in spea2_io.c */

int read_pop(char *filename, pop *pp, int size, int dim);
void write_pop(char *filename, pop *pp, int size);
int check_file(char *filename);


/*--------------------| qap functions |------------------------*/
#define MAX(A,B) ( (A > B) ? A : B) //Max operation.
#define MIN(A,B) ( (A < B) ? A : B) //Min operation.
#define EQUAL(A,B) ( (A == B) ? 1 : 0) //Equal operation.
#define NON_EQUAL(A,B) ( (A != B) ? 1 : 0) //Not equal operation.

qap * read_instance(char * instancefile); /* Loads the instance in the specified filename */
double evaluateAsLOP(int * genes, qap * problem); /* This function evaluates the individuals for the QAP problem. */

double evaluate_fc1(int * genes, qap * problem);
void calculateAverageComponents(qap * problem); /* Calculates the average fitness components of the
                                                 * elementary landscape decomposition needed to calculate the average fitness of a neighborhood in close form.
                                                 */
void evaluate_f_components(int * x, double * components, qap * problem); //Calculates the fitness value decomposed in the three components of the elementary landscape decomposition.

void printArray(int* array, int size); /* Prints in standard output 'length' double elements of a given array. */
void printMatrix(int** matrix, int length, int length2); /* Prints in the standard output given matrix. */
void print_pop(pop * pp); //Prints the population.
double average_fitness_pop(); double average_fitness_pop(pop * population); //returns the average population fitness.
double average_distance_pop(qap * problem);
double average_distance_pop(pop * population,qap * problem); //return the average cayley distance among the permutations in the population.
void generate_RandomPermutation(int * permutation, int n); /* Generates a random permutation of size 'n' in the given array.*/
void initialize_pop(pop * population); /* initializes the population of solutions with random permutations */
void evaluate_pop(pop * population, qap* problem); /* calculates the real fitness of the permutations and also de
                                                    first, second and third components values*/


void mating(qap * problem); /* Performs the mating of the selected individuals stored in pp_sel, 
                and stores the resulting individuals pp_off*/

ind* binary_tournament (ind * indiv1, ind * indiv2); /* checks which of the individuals is fitter.*/
void crossoverOPX (ind * parent1, ind * parent2, ind * child1, ind * child2 ); /* Crossover operator. OPX. */
void mutateSwap(int * genes, int size); /* Mutates the individual applying the flip mutation operator. */
bool remove(std::vector<int> * v, int element); /* Removes element from vector */

#endif /* SPEA2_H */
