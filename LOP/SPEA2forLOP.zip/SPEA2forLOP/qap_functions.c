//
//  qap_functions.cpp
//  SPEA2
//
//  Created by Josu Ceberio Uribe on 23/12/15.
//  Copyright © 2015 University of the Basque Country. All rights reserved.
//

#include "spea2.h"
#include <stdio.h>
#include <assert.h>
#include <vector>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>

using std::ifstream;
using std::ofstream;
using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::stringstream;
using std::string;

qap* read_instance(char * instancefile)
{
        //printf("Initializing... %d\n ",size);
    qap* problem;
    problem=(qap*)malloc(sizeof(qap));
    
    FILE* fp = fopen(instancefile, "r");
    assert(fp != NULL);
    int size,value,i,j;
    fscanf(fp, "%d",&size); /* read size */
    
    
    //printf("Initializing... %d\n ",size);
    /* initialize qap structure */
    problem->best=create_ind(size, 3);
    problem->size=size;
    problem->evaluations=0;
    problem->fc_avg=(double*)malloc(3*sizeof(double));
    problem->distance_matrix=(int**)malloc(size*sizeof(int*));
    problem->flow_matrix=(int**)malloc(size*sizeof(int*));
    for (i=0;i<size;i++){
        problem->distance_matrix[i]=(int*)malloc(size*sizeof(int));
        problem->flow_matrix[i]=(int*)malloc(size*sizeof(int));
    }
    
    // printf("distance...\n");
    /* read flow matrix */
    for (i=0;i<size;i++){
        for (j=0;j<size;j++){
            fscanf(fp,"%d",&value);
            problem->flow_matrix[i][j]=value;
            if (j<=i)
                problem->distance_matrix[i][j]=0;
            else
                problem->distance_matrix[i][j]=1;
        }
        // printf("\n");
    }
    //printMatrix(problem->distance_matrix, size, size);
    //printMatrix(problem->flow_matrix, size, size);

    calculateAverageComponents(problem);
    return (problem);
}

/*
 * This function evaluates the individuals for the QAP problem as LOP.
 */
double evaluateAsLOP(int * genes, qap * problem)
{
    double fitness=0;
    int i,j;
    for (i=0;i<problem->size-1;i++)
    {
        for (j=i+1;j<problem->size;j++){
            fitness+= problem->flow_matrix[genes[i]][genes[j]];
        }
    }
    return fitness;
}

/*
 * Omega 1.
 */
inline int Omega1(int i, int j, int p, int q, int * x, int n){
    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
        return -1; //rho
    if ((x[i]==p)^(x[j]==q))
        return -2; //gamma
    if ((x[i]==q)^(x[j]==p))
        return 0; //epsilon
    if ((x[i]==p)&&(x[j]==q))
        return n-3; //alpha.
    if ((x[i]==q)&&(x[j]==p))
        return 1-n; //beta
    cout<<"Error in Omega 1. "<<endl; exit(1);
}


/*
 * Calculates the fitness value corresponding to the first component of the elementary landscape decomposition.
 */
double evaluate_fc1(int * x, qap * problem){
    int i,j,p,q;
    double result=0;
    double psi;
    int n=problem->size;
    for (i=0;i<n;i++){
        for (j=i+1;j<n;j++){ //lower triangle of distance matrix is 0, and upper triangle 1.
            for (p=0;p<n;p++){
                for (q=0;q<p;q++){
                    psi=problem->flow_matrix[p][q];
                    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
                        result+= -psi; //rho
                    else if ((x[i]==p)^(x[j]==q))
                        result+= -2*psi; //gamma
                    //else if ((x[i]==q)^(x[j]==p))
                    //    result+= 0*psi; //epsilon
                    else if ((x[i]==p)&&(x[j]==q))
                        result+= (n-3)*psi; //alpha.
                    else if ((x[i]==q)&&(x[j]==p))
                        result+= (1-n)*psi; //beta
                }
                for (q=p+1;q<n;q++){
                    psi=problem->flow_matrix[p][q];
                    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
                        result+= -psi; //rho
                    else if ((x[i]==p)^(x[j]==q))
                        result+= -2*psi; //gamma
                    //else if ((x[i]==q)^(x[j]==p))
                    //    result+= 0*psi; //epsilon
                    else if ((x[i]==p)&&(x[j]==q))
                        result+= (n-3)*psi; //alpha.
                    else if ((x[i]==q)&&(x[j]==p))
                        result+= (1-n)*psi; //beta
                }
            }
        }
    }
    result=result/(double)(2*n);
    return result;
}



/*
 * Calculates the fitness value decomposed in the three components of the elementary landscape decomposition.
 */
void evaluate_f_components(int * x, double * components, qap * problem){
    int i,j,p,q;
    double psi;
    double result1=0, result2=0;//, result3=0;
    int n=problem->size;
    int n_3=n-3;
    for (i=0;i<n;i++){
        for (j=0;j<i;j++){
            for (p=0;p<n;p++){
                for (q=0;q<p;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                }
                for (q=p+1;q<n;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                    
                }
            }
        }
        for (j=i+1;j<n;j++){
            for (p=0;p<n;p++){
                for (q=0;q<p;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                }
                for (q=p+1;q<n;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                    
                }
            }
        }
    }
    components[0]=result1/(double)(2*n);
    components[1]=result2/(double)(2*(n-2));
    // components[2]=result3/(double)(n*(n-2));
}

/*
 * Calculates the average fitness components of the elementary landscape decomposition needed to calculate the average
 * fitness of a neighborhood in close form.
 */
void calculateAverageComponents(qap * problem){
    double phi=0;
    int i,j,p,q;
    int size= problem->size;
    for (i=0;i<size;i++){
        for (j=0;j<size;j++){
            for (p=0;p<size;p++){
                for (q=0;q<size;q++){
                    if (i!=j && p!=q)
                        phi+=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                }
            }
        }
    }
    problem->fc_avg[0]=- phi/(double)(2*size);
    problem->fc_avg[1]= phi * (size-3)/(double)(2*(size-2)*(size-1));
    problem->fc_avg[2]= phi/(double)(size*(size-2));
}

void printMatrix(int** matrix, int length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }
}

void printArray(int* array, int size)/* Prints in standard output 'length' double elements of a given array. */
{
    for (int i=0;i<size;i++){
        printf(" %d,",array[i]);
    }
    printf("\n ");
}

/*
 * Generates a random permutation of size 'n' in the given array.
 */
void generate_RandomPermutation(int * permutation, int n)
{
    int i,j;
    for (i = 0; i < n; i++)
    {
        j = rand() % (i + 1);
        permutation[i] = permutation[j];
        permutation[j] = i;
    }
}

void initialize_pop(pop * population){
    int i;
    for (i=0;i<population->size;i++)
    {
        generate_RandomPermutation(population->ind_array[i]->genes,population->ind_array[i]->size);
    }
}

void evaluate_pop(pop * population, qap * problem){
    int i;
    int i_best=-1;
    for (i=0;i<population->size;i++)
    {
        population->ind_array[i]->real_fitness=-evaluateAsLOP(population->ind_array[i]->genes, problem);
        
        population->ind_array[i]->f[0]=-evaluate_fc1(population->ind_array[i]->genes,problem);
        population->ind_array[i]->f[1]=-problem->fc_avg[1];
        population->ind_array[i]->f[2]=population->ind_array[i]->real_fitness-(population->ind_array[i]->f[0]+population->ind_array[i]->f[1]);
        
        problem->evaluations++;
        if (problem->best->real_fitness>population->ind_array[i]->real_fitness){
            i_best=i;
        }
    }
    if (i_best!=-1){
        memcpy(problem->best->f, population->ind_array[i_best]->f, sizeof(double)*3);
        problem->best->real_fitness=population->ind_array[i_best]->real_fitness;
        problem->best->fitness=population->ind_array[i_best]->fitness;
        problem->best->size=population->ind_array[i_best]->size;
        memcpy(problem->best->genes, population->ind_array[i_best]->genes, sizeof(int)*problem->best->size);
#ifdef VERBOSE
        printf("Best: %g  evals: %ld, f: %.5f, %.5f, %.5f\n ", problem->best->real_fitness, problem->evaluations, problem->best->f[0], problem->best->f[1], problem->best->f[2]);
#endif
    }
    
}

ind* binary_tournament (ind * indiv1, ind * indiv2){ //checks which of the individuals is fitter.
    
    if (dominates(indiv1,indiv2)){
//    if (indiv1->f[1]<indiv2->f[1] && indiv1->f[2]<indiv2->f[2]){
        return (indiv1);
    }
    if (dominates(indiv2,indiv1)){
//    if (indiv1->f[1]>indiv2->f[1] && indiv1->f[2]>indiv2->f[2]){
        return (indiv2);
    }
    if (indiv1->real_fitness<indiv2->real_fitness){
        return (indiv1);
    }
    if (indiv1->real_fitness>indiv2->real_fitness){
        return (indiv2);
    }
    if ((rand()/RAND_MAX) <= 0.5)
    {
        return(indiv1);
    }
    else
    {
        return(indiv2);
    }
}

void crossoverOPX (ind * parent1, ind * parent2, ind * child1, ind * child2 ){
    
    int i;
    int size=parent1->size;
    std::vector<int> non_used_parent1; int index_non_used1=0;
     std::vector<int> non_used_parent2; int index_non_used2=0;
    int element1,element2;
    for (i=0;i<size;i++) {
        element1=parent1->genes[i];
        element2=parent2->genes[i];
        if (EQUAL(element1, element2)==0){
            child1->genes[i]=-1;
            child2->genes[i]=-1;
            non_used_parent1.push_back(element1);
            non_used_parent2.push_back(element2);
        }
        else{
            child1->genes[i]=element1;
            child2->genes[i]=element2;
        }
    }
    
    int crossover_point= (rand()% (size-2));
    memcpy(child1->genes, parent1->genes, sizeof(int)*(crossover_point+1));
    memcpy(child2->genes, parent2->genes, sizeof(int)*(crossover_point+1));
    
    for (i=0;i<=crossover_point;i++){
        remove(&non_used_parent2, parent1->genes[i]);
        remove(&non_used_parent1, parent2->genes[i]);
    }
    
    for (i=crossover_point+1;i<size;i++){
        if (child1->genes[i]==-1){
            child1->genes[i]=non_used_parent2.at(index_non_used2);
            index_non_used2++;
        }
        if (child2->genes[i]==-1){
            child2->genes[i]=non_used_parent1.at(index_non_used1);
            index_non_used1++;
        }
    }
    non_used_parent1.clear();
    non_used_parent2.clear();
}

void mutateSwap(int * genes, int size){
    int i=rand()% size;
    int j=rand()% size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}

bool remove(std::vector<int> * v, int element){
    
    for (int i=0;i<v->size();i++){
        if (element==v->at(i)){
            v->erase(v->begin()+i);
            return true;
        }
    }
    return false;
}

