//
//  NSGA2.cpp
//  NSGA2forQAP
//
//  Created by Josu Ceberio Uribe on 02/07/14.
//  Copyright (c) 2014 Josu Ceberio Uribe. All rights reserved.
//

#include "NSGA2.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "DebtCode.hpp"

/*
 * The constructor.
 */
NSGA2::NSGA2(QAP * problem, int problem_size, long int max_evaluations)
{
    // cout<<"Constructing NSGA2..."<<endl;
    //1. standard initializations
    m_problem=problem;
    m_problem_size=problem_size;
    m_max_evaluations=max_evaluations;
    m_evaluations=0;
    m_convergence_evaluations=0;
    m_best= new CIndividual(problem_size);
    m_pop_size=m_problem_size*8;
    m_sel_size=m_pop_size;
    m_offspring_size= m_pop_size;
    //new set of parameters for the paper
    /*m_pop_size=m_problem_size;
    m_sel_size=m_pop_size;
    m_offspring_size= m_problem_size/2;
    if (m_sel_size%2!=0){
        m_sel_size++;
    }
    if (m_offspring_size%2!=0){
        m_offspring_size++;
    }
    cout<<"Sel size: "<<m_sel_size<<" off size: "<<m_offspring_size<<endl;*/
    m_parent_pop = new CPopulation(m_pop_size, m_problem_size);
    m_child_pop = new CPopulation(m_offspring_size,m_problem_size);
    m_mixed_pop = new CPopulation(m_pop_size+m_offspring_size, m_problem_size);
    m_selection_a1 = new int[m_pop_size];
    m_selection_a2 = new int[m_pop_size];
}

/*
 * The destructor. It frees the memory allocated..
 */
NSGA2::~NSGA2()
{
  //  cout<<"Destructing NSGA2..."<<endl;
//    delete m_best; //it is included in the population.
    delete m_parent_pop;
    delete m_child_pop;
    delete m_mixed_pop;
    
    
    delete [] m_selection_a1;
    delete [] m_selection_a2;
}
/*
 * Routine for tournament selection, it creates a new_pop from old_pop by performing tournament selection and the crossover
 */
void NSGA2::Selection (CPopulation *old_pop, CPopulation *new_pop){

    int temp;
    int i;
    int r;
    CIndividual *parent1, *parent2;

    for (i=0; i<old_pop->m_pop_size; i++)
    {
        m_selection_a1[i] = m_selection_a2[i] = i;
    }
   for (i=0; i<old_pop->m_pop_size; i++)
    {
        r = i+(rand()%(old_pop->m_pop_size-i));
        temp = m_selection_a1[r];
        m_selection_a1[r] = m_selection_a1[i];
        m_selection_a1[i] = temp;
         r = i+(rand()%(old_pop->m_pop_size-i));
        temp = m_selection_a2[r];
        m_selection_a2[r] = m_selection_a2[i];
        m_selection_a2[i] = temp;
    }
    for (i=0; i<new_pop->m_pop_size; i+=4)
    {
        
        parent1 = Tournament (old_pop->m_individuals[m_selection_a1[i]], old_pop->m_individuals[m_selection_a1[i+1]]);
        parent2 = Tournament (old_pop->m_individuals[m_selection_a1[i+3]], old_pop->m_individuals[m_selection_a1[i+2]]);
        Crossover_OPX (parent1, parent2, new_pop->m_individuals[i], new_pop->m_individuals[i+1]);
        
        parent1 = Tournament (old_pop->m_individuals[m_selection_a2[i]], old_pop->m_individuals[m_selection_a2[i+1]]);
        parent2 = Tournament (old_pop->m_individuals[m_selection_a2[i+2]], old_pop->m_individuals[m_selection_a2[i+3]]);
        Crossover_OPX (parent1, parent2, new_pop->m_individuals[i+2], new_pop->m_individuals[i+3]);
    }
}
int Contains(vector<int>v, int element){
    
    for (int i=0;i<v.size();i++)
        if (element==v[i])
            return i;
    return -1;
}

bool Remove(vector<int> * v, int element){

    for (int i=0;i<v->size();i++){
        if (element==v->at(i)){
            v->erase(v->begin()+i);
            return true;
        }
    }
    return false;
}

/*
 * Crossover operator. ULX
 */
void NSGA2::Crossover_ULX (CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2 ){
    
    int i;
    vector<int> nonassigned_child1;
    vector<int> nonassigned_child2;
    
    for (i=0;i<m_problem_size;i++) {
        if (parent1->m_genes[i]!=parent2->m_genes[i]){
            child1->m_genes[i]=-1;
            child2->m_genes[i]=-1;
            nonassigned_child1.push_back(parent1->m_genes[i]);
            nonassigned_child2.push_back(parent1->m_genes[i]);
        }
        else{
            child1->m_genes[i]=parent1->m_genes[i];
            child2->m_genes[i]=parent1->m_genes[i];
        }
    }

    int element;
    for (i=0;i<m_problem_size;i++){
        if (child1->m_genes[i]==-1){
            if (((float)rand()/(float)RAND_MAX)<0.5){
                element=parent1->m_genes[i];
            }
            else{
                element=parent2->m_genes[i];
            }
            if (Remove(&nonassigned_child1, element)==true){
                child1->m_genes[i]=element;
            }
        }
        if (child2->m_genes[i]==-1){
            if (((float)rand()/(float)RAND_MAX)<0.5)
                element=parent1->m_genes[i];
            else
                element=parent2->m_genes[i];
            if (Remove(&nonassigned_child2, element)){
                child2->m_genes[i]=element;
            }
        }
        
    }

    int index1=0, index2=0;
    for (i=0;i<m_problem_size;i++){
        if (child1->m_genes[i]==-1){
            child1->m_genes[i]=nonassigned_child1[index1];
            index1++;
        }
        if (child2->m_genes[i]==-1){
            child2->m_genes[i]=nonassigned_child2[index2];
            index2++;
        }
    }

}

/*
 * Crossover operator. OPX
 */
inline void NSGA2::Crossover_OPX (CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2 ){

    int i;
    vector<int> non_used_parent1; int index_non_used1=0;
    vector<int> non_used_parent2; int index_non_used2=0;
    int element1,element2;
    for (i=0;i<m_problem_size;i++) {
        element1=parent1->m_genes[i];
        element2=parent2->m_genes[i];
        if (EQUAL(element1, element2)==0){
            child1->m_genes[i]=-1;
            child2->m_genes[i]=-1;
            non_used_parent1.push_back(element1);
            non_used_parent2.push_back(element2);
        }
        else{
            child1->m_genes[i]=element1;
            child2->m_genes[i]=element2;
        }
    }
    
    int crossover_point= (rand()% (m_problem_size-2));
    memcpy(child1->m_genes, parent1->m_genes, sizeof(int)*(crossover_point+1));
    memcpy(child2->m_genes, parent2->m_genes, sizeof(int)*(crossover_point+1));
    
    for (i=0;i<=crossover_point;i++){
        Remove(&non_used_parent2, parent1->m_genes[i]);
        Remove(&non_used_parent1, parent2->m_genes[i]);
    }
    
    for (i=crossover_point+1;i<m_problem_size;i++){
        if (child1->m_genes[i]==-1){
            child1->m_genes[i]=non_used_parent2.at(index_non_used2);
            index_non_used2++;
        }
        if (child2->m_genes[i]==-1){
            child2->m_genes[i]=non_used_parent1.at(index_non_used1);
            index_non_used1++;
        }
    }
    non_used_parent1.clear();
    non_used_parent2.clear();
}

/*
 * Tournament.
 */
inline CIndividual * NSGA2::Tournament (CIndividual * ind1, CIndividual * ind2){
    
    int dominance=Dominates(ind1,ind2);
    if (dominance==0){
//    if (ind1->m_fc2<ind2->m_fc2 && ind1->m_fc3<ind2->m_fc3){
        return (ind1);
    }
    if (dominance==1){
    //if (ind1->m_fc2>ind2->m_fc2 && ind1->m_fc3>ind2->m_fc3){
        return (ind2);
    }
    if (ind1->m_value>ind2->m_value){
        return (ind1);
    }
    if (ind1->m_value<ind2->m_value){
        return (ind2);
    }
    if ((rand()/RAND_MAX) <= 0.5)
    {
        return(ind1);
    }
    else
    {
        return(ind2);
    }
}

/*
 * Evaluates the individuals in the population.
 */
void NSGA2::Evaluate_Pop(CPopulation * population){
    
    int i;
    CIndividual *g;

    for (i=0;i<population->m_pop_size;i++){
        g=population->m_individuals[i];
        g->m_value=m_problem->EvaluateAsLOP(g->m_genes);
        if (MODE != 0 || PRINT_POPULATION!=0){
   
            //calculate the three components.
            //m_problem->f_components(g->m_genes,g->m_fc);
            g->m_fc[0]=m_problem->fc1(g->m_genes);
            g->m_fc[1]=m_problem->fc2_avg;
            g->m_fc[2]=g->m_value-g->m_fc[0]-g->m_fc[1];

        }
    }
   
    m_evaluations=m_evaluations+population->m_pop_size;
}

/*
 * Mutates the individual applying the flip mutation operator.
 */
void NSGA2::Mutate_Swap(int * genes){
    int i=rand()% m_problem_size;
    int j=rand()% m_problem_size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}

/*
 * Mutates the individual applying the reverse mutation operator.
 */
void NSGA2::Mutate_Reverse(int * genes){
    int i=rand()% m_problem_size;
    int j=rand()% m_problem_size;

    int index,min,max;
    min=MIN(i,j);
    max=MAX(i,j);

    int gap_size=max-min+1;
    int *aux= new int[gap_size];
    memcpy(aux,&genes[min],sizeof(int)*gap_size);
    for (index=0;index<gap_size;index++)
    {
        genes[min+index]=aux[gap_size-1-index];
    }
    delete [] aux;
}

/*
 * Mutates the individuals in the population.
 */
void NSGA2::Mutate_Pop(CPopulation * population){
    int i;
    CIndividual *g;
    for (i=0;i<population->m_pop_size;i++){
        g=population->m_individuals[i];
        Mutate_Swap(g->m_genes);
    }
}

/*
 * Routine to merge two populations into one
 */
void NSGA2::Merge(CPopulation *pop1, CPopulation *pop2, CPopulation *pop3)
{
    int i, k;
    for (i=0; i<pop1->m_pop_size; i++)
    {
        Copy_Ind(pop1->m_individuals[i], pop3->m_individuals[i]);
    }
    for (i=0, k=pop1->m_pop_size; i<pop2->m_pop_size; i++, k++)
    {
        Copy_Ind(pop2->m_individuals[i], pop3->m_individuals[k]);
    }
    return;
}





/*
 * Running function
 */
int NSGA2::Run(){

#ifdef VERBOSE
     cout<<"Running NSGA2..."<<endl;
#endif
    /////////////////////////////////////////////////
    //1. Initialize population randomly and evaluate
    /////////////////////////////////////////////////

    double f;
    int * genes= new int[m_problem_size];
    int i;
    double * fc= new double[3];
    for(i=0;i<m_pop_size;i++)
    {
        //Create random individual
        GenerateRandomPermutation(genes,m_problem_size);
        f=m_problem->EvaluateAsLOP(genes);
        
        if (MODE != 0 || PRINT_POPULATION!=0){
            fc[0]=m_problem->fc1(genes);
            fc[1]=m_problem->fc2_avg;
            //fc3=m_problem->fc3_basic(genes);
            //fc3=m_problem->fc3(genes);
            //fc2=m_problem->fc2_avg;
            fc[2]=f-fc[0]-fc[1];
            //m_problem->f_components(genes,fc);
           // cout<<"evaluation: "<<f<<" components sum: "<<fc[0]+fc[1]+fc[2]<<endl;
        }
        m_parent_pop->SetToPopulation(genes, i, f,fc);
        m_evaluations++;
    }
    delete [] genes;
    delete [] fc;

    m_best->m_value=MIN_INTEGER;
    /////////////////////////////////////////////////
    //2. Non-dominated fast sorting
    /////////////////////////////////////////////////
    if (MODE==1)
        m_parent_pop->Fast_NonDominatedSorting_Adapted(m_best);
    else if (MODE==2){
        assign_rank_and_crowding_distance(m_parent_pop,m_best);
    }
    else
        m_parent_pop->SortPopulation(m_best);

    /////////////////////////////////////
    //3. Start the iterative process
    /////////////////////////////////////
    bool improved=false;
    int iteration=0;
#ifdef PRINT_CONVERGENCE_DATA
    cout<<"Iteration, AverageDistance, AverageFitness"<<endl;
#endif
#ifdef PRINT_POPULATION
            if (PRINT_POPULATION==1){
    cout<<"Iteration, ID, f, fc1, fc2, fc3"<<endl;
            }
#endif
    while (m_evaluations<m_max_evaluations){
        
#ifdef PRINT_CONVERGENCE_DATA
        if ((iteration%5) ==0 )
            printf("%d,%.2f,%.2f\n",m_evaluations,m_parent_pop->AverageDistancePopulation(m_pop_size),m_parent_pop->AverageFitnessPopulation(m_pop_size));
        if (iteration==500)
            exit(1);
#endif

        if (PRINT_POPULATION==1){
            if ((iteration%5) ==0 ){
                for (i=0;i<m_parent_pop->m_pop_size;i++)
                    printf("%d,%d,%.2f,%.2f,%.2f,%.2f\n",
                           iteration,
                           i,
                       m_parent_pop->m_individuals[i]->m_value,
                       m_parent_pop->m_individuals[i]->m_fc[0],
                       m_parent_pop->m_individuals[i]->m_fc[1],
                       m_parent_pop->m_individuals[i]->m_fc[2]);
                if (iteration==500)
                    exit(1);
            }
        }


        Selection(m_parent_pop, m_child_pop);
        //cout<<"1.mutate"<<endl;
        Mutate_Pop(m_child_pop);
        //cout<<"1.evaluate"<<endl;
        Evaluate_Pop(m_child_pop);
        //cout<<"1.merge"<<endl;
        Merge(m_parent_pop,m_child_pop,m_mixed_pop);
        if (MODE == 1)
            improved=m_mixed_pop->Fast_NonDominatedSorting_Adapted(m_best);
        else if (MODE==2){
            improved= Fast_NonDominatedSorting_Original(m_mixed_pop, m_parent_pop, m_best);
        }
        else
            improved=m_mixed_pop->SortPopulation(m_best);
        
        if (MODE!=2){
            for (i=0; i<m_pop_size; i++)
                Copy_Ind(m_mixed_pop->m_individuals[i], m_parent_pop->m_individuals[i]);
        }
#ifdef VERBOSE
        if (improved)
            //cout<<"B: "<<m_best->m_value<<" E: "<<m_evaluations<<endl;
            printf("%f,%d,%.1f,%.1f,%f\n",m_best->m_value,m_evaluations,m_best->m_fc[0],m_best->m_fc[1],m_best->m_fc[2]);
#endif
        iteration++;
    }

    return m_best->m_value;
}

/*
 * Returns the fitness of the best solution obtained.
 */
int NSGA2::GetBestSolutionFitness(){
    return m_best->m_value;
}

/*
 * Returns the best solution obtained.
 */
CIndividual * NSGA2::GetBestSolution(){
    return m_best;
}
