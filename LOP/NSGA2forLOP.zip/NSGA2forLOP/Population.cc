//
//  Population.cc
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#include "Population.h"

using std::istream;
using std::ostream;
using std::cerr;
using std::cout;
using std::endl;

/*
 * Constructor function.
 */
CPopulation::CPopulation(int pop_size, int individual_size)
{
    m_pop_size=pop_size;
    m_individuals.resize(m_pop_size);
    m_problem_size=individual_size;
    
    //Initialize population with empty solutions
    for (int i=0;i<m_pop_size;i++)
    {
        m_individuals[i]= new CIndividual(individual_size);
    }
    
    m_n=new int[m_pop_size];
    m_marks= new int[m_pop_size];
    
}

/*
 * Destructor function.
 */
CPopulation::~CPopulation()
{
    for (int i=0;i<m_pop_size;i++)
    {
        delete m_individuals[i];
    }
    m_individuals.clear();
    delete [] m_n;
    delete [] m_marks;
}

/*
 * Function to set an individual in a specific position of the population
 */
void CPopulation::SetToPopulation(int * genes, int index, int fitness, double * fc)
{
    memcpy( m_individuals[index]->m_genes, genes, sizeof(int)*m_problem_size);
    m_individuals[index]->m_value=fitness;
    memcpy( m_individuals[index]->m_fc, fc, sizeof(double)*3);
}

/*
 *
 */
bool CPopulation::Exists(int index, int fitness){

    bool exists=true;
    int bound= m_pop_size+index;
    int i;
    for(i=0;i<bound && fitness!=m_individuals[i]->m_value; i++);
    if (i==bound)
        exists=false;
    return exists;
}

/*
 * Prints the current population.
 */
void CPopulation::Print(int samples)
{
	for(int i=0;i<samples; i++)
        printf("ID: %d, %.1f, [%.1f,%.1f,%.1f]\n",i,m_individuals[i]->m_value,m_individuals[i]->m_fc[0],m_individuals[i]->m_fc[1],m_individuals[i]->m_fc[2]);
}



/*
 * Calculates the average fitness of the first 'size' solutions in the population
 */
float CPopulation::AverageFitnessPopulation(int size)
{
	float result=0;
	for(int i=0;i<size;i++)
    {
        result+=m_individuals[i]->m_value;
    }
    return result/size;
    
}

/*
 * Returns the best individual of the population.
 */
CIndividual * CPopulation::BestIndividual(){
    int best_index=0;

    for (int i=1;i<m_pop_size;i++){
        if (m_individuals[i]->m_value<m_individuals[best_index]->m_value)
            best_index=i;
    }
    return m_individuals[best_index];
}

/*
 * Sorts the individuals in the population in ascending order of the fitness value.
 * returns true if the best solution was outperformed.
 */
bool CPopulation::SortPopulation(CIndividual * best)
{
    sort(m_individuals.begin(), m_individuals.begin()+m_pop_size, Better);
    if (m_individuals[0]->m_value>best->m_value){
        Copy_Ind(m_individuals[0], best);
        return true;
    }
    return false;
}

/*
 *  Performs the nondominated sorting of the NSGA-II proposed by debt et al, and adapted by J. Ceberio to truncate the last pareto.
 */
bool CPopulation::Fast_NonDominatedSorting_Adapted(CIndividual * best){
    
    int p,q;
    bool improved=false;
    m_S.resize(m_pop_size);
    m_F.resize(1);
    m_clone.resize(0);
   // cout<<" ----------------------------------------------------------------- "<<endl;
   // this->Print(m_pop_size);
   // cout<<"Pop size: "<<m_pop_size<<endl;
    
    //first pareto.
    int dominance;
    for (p=0;p<m_pop_size;p++){
        m_S[p].resize(0);
        m_n[p]=0;
        for (q=0;q<p;q++){
            dominance=Dominates(m_individuals[p],m_individuals[q]);
            if (dominance==0){//p dominates q
//          if (m_individuals[p]->m_fc2<m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3<=m_individuals[q]->m_fc3){ //p dominates q
                m_S[p].push_back(q);
            }
            else if (dominance==1){//increment the domination counter of p
//          else if (m_individuals[p]->m_fc2>m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3>=m_individuals[q]->m_fc3){//increment the domination counter of p
                m_n[p]++;
            }
        }
        for (q=p+1;q<m_pop_size;q++){
            dominance=Dominates(m_individuals[p],m_individuals[q]);
            if (dominance==0){//p dominates q
            //              if (m_individuals[p]->m_fc2<m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3<=m_individuals[q]->m_fc3){ //p dominates q
                m_S[p].push_back(q);
            }
            else if (dominance==1){//increment the domination counter of p
                //              else if (m_individuals[p]->m_fc2>m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3>=m_individuals[q]->m_fc3){//increment the domination counter of p
                m_n[p]++;
            }
        }
        
        if (m_n[p]==0){ //p belongs to the first front.
            m_marks[p]=1;
            m_F[0].push_back(p);
        }
    }
    int i=0; //initialize the front counter.
    int z,w;

    while(!m_F[i].empty()){
        m_F.resize(m_F.size()+1);
        for (z=0;z<m_F[i].size();z++){
            p=m_F[i][z];
            
            for (w=0;w<m_S[p].size();w++){
                q=m_S[p][w];
                m_n[q]--;
                if (m_n[q]==0){ //q belongs to the next front.
                    m_marks[q]=i+2;
                    m_F[i+1].push_back(q);
                }
            }
        }
        i++;
    }

    //Print detected fronts.
    //for (int x=0;x<m_F.size();x++){
    //    cout <<"The front "<<x<<" :  ";
    //    for (int y=0;y<m_F[x].size();y++){
    //        cout<< m_F[x][y]<<" ";
    //    }
    //    cout<<endl;
    //}
    
    m_F.resize(m_F.size()-1);
    int a=0, b=0, j;
    for (i=0;i<m_F.size();i++){
        for (j=0;j<m_F[i].size();j++){
            m_clone.push_back(m_individuals[m_F[i][j]]);
        }
        b=b+(int)m_F[i].size();
        sort(m_clone.begin()+a,m_clone.begin()+b,Better);
        if (m_clone[a]->m_value>best->m_value){
            Copy_Ind(m_clone[a],best);
            improved=true;
        }
        a=b;
    }
    m_individuals.clear();
    m_individuals=m_clone;
    m_F.clear();
    m_S.clear();
    m_clone.clear();
    //this->Print(m_pop_size);

    return improved;
}


/*
 *  Calculates the paretos in the population
 */
bool CPopulation::CalculateParetos(int num_samples){
    int p,q;
    bool improved=false;
    m_S.resize(num_samples);
    m_F.resize(1);
    // cout<<" ----------------------------------------------------------------- "<<endl;
    // this->Print(m_pop_size);
    // cout<<"Pop size: "<<m_pop_size<<endl;
    
    //first pareto.
    int dominance;
    for (p=0;p<num_samples;p++){
        m_S[p].resize(0);
        m_n[p]=0;
        for (q=0;q<p;q++){
            dominance=Dominates(m_individuals[p],m_individuals[q]);
            if (dominance==0){//p dominates q
                //          if (m_individuals[p]->m_fc2<m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3<=m_individuals[q]->m_fc3){ //p dominates q
                m_S[p].push_back(q);
            }
            else if (dominance==1){//increment the domination counter of p
                //          else if (m_individuals[p]->m_fc2>m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3>=m_individuals[q]->m_fc3){//increment the domination counter of p
                m_n[p]++;
            }
        }
        for (q=p+1;q<num_samples;q++){
            dominance=Dominates(m_individuals[p],m_individuals[q]);
            if (dominance==0){//p dominates q
                //              if (m_individuals[p]->m_fc2<m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3<=m_individuals[q]->m_fc3){ //p dominates q
                m_S[p].push_back(q);
            }
            else if (dominance==1){//increment the domination counter of p
                //              else if (m_individuals[p]->m_fc2>m_individuals[q]->m_fc2 && m_individuals[p]->m_fc3>=m_individuals[q]->m_fc3){//increment the domination counter of p
                m_n[p]++;
            }
        }
        
        if (m_n[p]==0){ //p belongs to the first front.
            m_marks[p]=1;
            m_F[0].push_back(p);
        }
    }
    int i=0; //initialize the front counter.
    int z,w;
    
    while(!m_F[i].empty()){
        m_F.resize(m_F.size()+1);
        for (z=0;z<m_F[i].size();z++){
            p=m_F[i][z];
            
            for (w=0;w<m_S[p].size();w++){
                q=m_S[p][w];
                m_n[q]--;
                if (m_n[q]==0){ //q belongs to the next front.
                    m_marks[q]=i+2;
                    m_F[i+1].push_back(q);
                }
            }
        }
        i++;
    }

    m_F.resize(m_F.size()-1);
    //Print detected fronts.
    for (int x=0;x<m_F.size();x++){
        cout <<"The front "<<x<<" :  ";
        for (int y=0;y<m_F[x].size();y++){
            cout<< m_F[x][y]<<" ";
        }
        cout<<endl;
    }
    
/*    cout<<"; "<<m_F.size()<<";  [";
    double mean=0;
    double std=0;
    double normalized_std=0;
    for (int x=0;x<m_F.size();x++){
        cout<<m_F[x].size();
        if (x!=m_F.size()-1)
            cout<<",";
    }
    cout<<"]; [";
    
    int front_size;
    for (int x=0;x<m_F.size();x++){
        front_size=m_F[x].size();
        double * fitnessData= new double[front_size];
        for (int y=0;y<front_size;y++){
            fitnessData[y]=m_individuals[m_F[x][y]]->m_value;
        }
        
        mean=getMean(fitnessData,front_size);
        std=sqrt(getVariance(fitnessData,front_size));
        normalized_std=std/mean;
        cout<<normalized_std;
        if (x!=m_F.size()-1)
            cout<<",";
        delete [] fitnessData;
    }
    cout<<"]; "<<endl;
    
    m_F.clear();
    m_S.clear();*/
    return improved;
}

/*
 * Calculates the average distance of the first 'size' solutions in the population
 */
float CPopulation::AverageDistancePopulation(int size){
    float result=0;
    int i,j;
    int problem_size=m_individuals[i]->m_size;
    float comparations=size*(size-1)/2;
    for(i=0;i<size;i++)
    {
        for (j=i+1;j<size;j++){
            result+=Cayley(m_individuals[i]->m_genes,m_individuals[j]->m_genes,problem_size);
        }
    }
    return result/comparations;
    
}



