//
//  main.cpp
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include "NSGA2.h"
#include "FAP.hpp"
#include "Individual.h"


//It is the instance of the problem to optimize.
FAP * PROBLEM;

// The individual size.
int PROBLEM_SIZE=0;

// Number of evaluations performed.
long int EVALUATIONS = 0;

// Convergence evaluation of the best fitness.
long int CONVERGENCE_EVALUATIONS = 0;

// Maximum number of evaluations allowed performed.
long int MAX_EVALUATIONS = 0;

// Name of the file where the result will be stored.
char RESULTS_FILENAME[100];

// Name of the file where the instances is stored.
char INSTANCE_FILENAME[50];

// The seed asigned to the process
int SEED;

//Determines if a solution needs to be inverted before evaluating.
int INVERSE;


/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
	
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
	
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
		
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
			
            if (isalnum(chOpt) || ispunct(chOpt))
            {
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
				
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
							
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
	
    iArg++;
	
    *ppszParam = pszParam;
    return (chOpt);
}

/*
 * Help command output.
 */
void usage(char *progname)
{
    cout << "NSGA -i <instance_name> -o <results_name> -s <seed> " <<endl;
    cout <<"   -i File name of the instance.\n"<<endl;
    cout <<"   -o Name of the file to store the results.\n"<<endl;
    cout <<"   -s Seed to be used for pseudo-random numbers generator.\n"<<endl;
}

/*
 * Obtaint the execution parameters from the command line.
 */
bool GetParameters(int argc,char * argv[])
{
	char c;
    if(argc==1)
    {
    	usage(argv[0]);
        return false;
    }
	char** optarg;
	optarg = new char*[argc];
    while ((c = GetOption (argc, argv, ":h:s:o:i:v:",optarg)) != '\0')
    {
    	switch (c)
    	{
                
            case 'h' :
                usage(argv[0]);
                return false;
                break;
                
            case 's' :
                SEED = atoi(*optarg);
                break;
                
            case 'o' :
                strcpy(RESULTS_FILENAME, *optarg);
                break;
                
			case 'i':
                strcpy(INSTANCE_FILENAME, *optarg);
                break;
                
            default:
                cout<<"Wrong parameter specification... "<<endl;
                exit(1);
		
        }
    }

    delete [] optarg;
    
	return true;
}

/*
 * Writes the results of the execution.
 */
void WriteResults(long int best_fitness, int * best, long double time_interval){

    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file<<"Best fitness: "<<setprecision(15)<<best_fitness<<endl;
    output_file<<"Best solution: ";
    for (int i=0;i<PROBLEM_SIZE;i++)
        output_file<<best[i]<<" ";
    output_file<<endl;
    output_file<<"Time consumed: "<<time_interval<<endl;
    output_file.close();
}


/*
 * Main function.
 */
int main(int argc, char * argv[])
{
    //Initialize time variables.
    struct timeval tim;
    gettimeofday(&tim, NULL);
    double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    //Get parameters
#ifdef VERBOSE
     cout<<"Parsing parameters..."<<endl;
#endif
	if(!GetParameters(argc,argv)) return -1;

    //Set seed
    srand(SEED*1000);
    //Read the problem instance to optimize.
#ifdef VERBOSE
    cout<<"Reading instance..."<<INSTANCE_FILENAME;
#endif
    PROBLEM= new FAP();
    PROBLEM_SIZE= PROBLEM->Read(INSTANCE_FILENAME);
    
  //  for (int freq=20;freq<=60;freq=freq+20){
  //      for (int id=1;id<=5;id++){
  //          PROBLEM->CreateInstance(75, freq, id);
  //      }
  //  }
  //  exit(1);
    
    //PROBLEM_SIZE= PROBLEM->RandomInstance();
    MAX_EVALUATIONS=PROBLEM_SIZE*PROBLEM_SIZE*100;

#ifdef VERBOSE
    cout<<"Building NSGA2...."<<endl;
#endif
    NSGA2 * nsga2= new NSGA2(PROBLEM,PROBLEM_SIZE, MAX_EVALUATIONS);
    nsga2->Run(INSTANCE_FILENAME);
    
    //Get best solution fitness and the number of evaluations performed.
    CIndividual * best = nsga2->GetBestSolution();
    
    
    gettimeofday(&tim, NULL);
    double t2=tim.tv_sec+(tim.tv_usec/1000000.0);

    //Create the file to store the results.
    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file.close();
#ifdef VERBOSE
    cout<<"B: "<<best->m_value<<endl;
#endif
    
#ifndef KALIMERO
    //Local executions
    FILE * test= fopen("/Users/Josu/Desktop/resultsFAP.csv","r");
    FILE * result_file= fopen("/Users/Josu/Desktop/resultsFAP.csv","a+");
    if (test==NULL){
        fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    }
#ifndef EXEC_NSGA2
        fprintf(result_file,"\"%s\";%d;\"%s\";%g;%.3f\n",INSTANCE_FILENAME,SEED,"SGA",best->m_value,t2-t1);
#else
    if (EXEC_NSGA2==1) //adapted NSGA2
        fprintf(result_file,"\"%s\";%d;\"%s\";%g;%.3f\n",INSTANCE_FILENAME,SEED,"NSGA2_adap",best->m_value,t2-t1);
    else //if (MODE==2) //original NSGA2
        fprintf(result_file,"\"%s\";%d;\"%s\";%g;%.3f\n",INSTANCE_FILENAME,SEED,"NSGA2_orig",best->m_value,t2-t1);
#endif
    fclose(result_file);
    fclose(test);
#endif
    
#ifdef KALIMERO
    //In Kalimero
    FILE * result_file= fopen(RESULTS_FILENAME,"w");
    //fprintf(result_file,"\"Instance\";\"Repetition\";\"Algorithm\";\"Fitness\";\"Time\"\n");
    #ifndef EXEC_NSGA2
        fprintf(result_file,"\"%s\";%d;\"%s\";%g;%.3f\n",INSTANCE_FILENAME,SEED,"SGA",best->m_value,t2-t1);
    #else
    if (EXEC_NSGA2==1) //adapted NSGA2
        fprintf(result_file,"\"%s\";%d;\"%s\";%g;%.3f\n",INSTANCE_FILENAME,SEED,"NSGA2_adap",best->m_value,t2-t1);
    else //if (EXEC_NSGA2==2) //original NSGA2
        fprintf(result_file,"\"%s\";%d;\"%s\";%g;%.3f\n",INSTANCE_FILENAME,SEED,"NSGA2_orig",best->m_value,t2-t1);
    #endif
    fclose(result_file);
#endif
    
    delete best;
    delete PROBLEM;
    delete nsga2;
    
    return 0;
}

