//
//  FAP.cpp
//  NSGA2forFAP
//
//  Created by Josu Ceberio Uribe on 06/03/17.
//  Copyright © 2017 University of the Basque Country. All rights reserved.
//

#include "FAP.hpp"
#include <time.h>
#include <stdlib.h>
#include <string>
/*
 *Class constructor.
 */
FAP::FAP()
{
    
}

/*
 * Class destructor.
 */
FAP::~FAP()
{
    int i,j,p;
    for (i=0;i<m_size;i++)
    {
        for (j=0;j<m_size;j++)
        {
            for (p=0;p<m_number_of_channels;p++)
            {
                delete [] m_w[i][j][p];
            }
            delete [] m_w[i][j];
        }
        delete [] m_w[i];
    }
    delete [] m_w;
}



int FAP::Read(char * instancefile)
{
    FILE* f=fopen(instancefile,"r+");
    if ( f==NULL){
        printf("\n ERROR: unable to read FAP instance file.\n"); exit(1);
    }
    int id;
    int trash,trash1,trash2,trash3;

    fscanf(f,"%d %d %d",&m_size,&m_number_of_channels,&id);
    int i,j,p,q;
    float weight;
    m_w= new float***[m_size];
    for (i=0;i<m_size;i++)
    {
        m_w[i]=new float**[m_size];
        for (j=0;j<m_size;j++)
        {
            m_w[i][j]=new float*[m_number_of_channels];
            for (p=0;p<m_number_of_channels;p++)
            {
                m_w[i][j][p]=new float[m_number_of_channels];
                for (q=0;q<m_number_of_channels;q++){
                    
                    fscanf(f,"%d, %d, %d, %d, %f",&trash,&trash1,&trash2,&trash3,&weight);
                    m_w[i][j][p][q]=weight;
                }
            }
        }

    }
#ifdef VERBOSE
    printf("...OK!!\n");
#endif
    return m_size;
}

int FAP::RandomInstance()
{
    m_size=1+(rand()%99); //number of transceivers. Set randomly.
    m_number_of_channels=1+rand()%(m_size-1);//number of channels. Set randomly.
    cout<<"#transceivers: "<<m_size<<"   #channels: "<<m_number_of_channels<<endl;
    m_w= new float***[m_size];
    int i,j,p,q;
    int min=1;
    int max=10;
    for (i=0;i<m_size;i++)
    {
        m_w[i]=new float**[m_size];
        for (j=0;j<m_size;j++)
        {
            m_w[i][j]=new float*[m_number_of_channels];
            for (p=0;p<m_number_of_channels;p++)
            {
                m_w[i][j][p]=new float[m_number_of_channels];
                for (q=0;q<m_number_of_channels;q++){
                    m_w[i][j][p][q]=(rand()%(max-min))+min;
                }
            }
        }
    }
    /*
    for (i=0;i<m_size;i++)
    {
        for (j=i+1;j<m_size;j++)
        {
            for (p=0;p<m_number_of_channels;p++)
            {
                for (q=p+1;q<m_number_of_channels;q++){
                    m_w[j][i][q][p]=m_w[i][j][p][q];
                }
            }
        }
    }*/
    
    return (m_size);
}

void FAP::CreateInstance(int transceivers, int channels, int id){
    /* m_size=transceivers;
    m_number_of_channels=channels;

#ifdef VERBOSE
    cout<<endl;
    cout<<"creating instance..."<<endl;
#endif
    int i,j,p,q;
    
    float ** weights= new float*[m_size];
    for (i=0;i<m_size;i++){
        weights[i]= new float[m_size];
        fill_n(weights[i], m_size, 1.0);
    }
    //matrix of distances between nodes for weighting
    for (i=0;i<m_size;i++){
        for (j=i+1;j<m_size;j++){
            weights[i][j]=1.0/(float)(j-i+1);
            //cout<<"i: "<<i<<" j: "<<j<<" weight: "<<weights[i][j]<<endl;
            weights[j][i]=weights[i][j];
        }
    }
#ifdef VERBOSE
   // PrintMatrix(weights, m_size, m_size, "");
#endif
    int min=m_size;
    int max=m_size*m_size;
    float value;
    m_w= new float***[m_size];
    //allocate memory for instance
    for (i=0;i<m_size;i++)
    {
        m_w[i]=new float**[m_size];
        for (j=0;j<m_size;j++)
        {
            m_w[i][j]=new float*[m_number_of_channels];
            for (p=0;p<m_number_of_channels;p++)
            {
                m_w[i][j][p]=new float[m_number_of_channels];
            }
        }
    }
   
    for (i=0;i<m_size;i++)
    {
        for (j=i;j<m_size;j++)
        {
            for (p=0;p<m_number_of_channels;p++)
            {
                for (q=p;q<m_number_of_channels;q++){
                    value=((float)(min+(rand()%(max-min))))*weights[i][j];
                    m_w[i][j][p][q]=value;
                    m_w[i][j][q][p]=value;
                    m_w[j][i][p][q]=value;
                    m_w[j][i][q][p]=value;
                }
            }
        }
    }
    
    // write instance in file.
    string filename = "/Users/Josu/Desktop/cebe" + to_string(transceivers) + "_" + to_string(channels) + "_" + to_string(id) + ".fap";
    FILE * f= fopen(filename.c_str(),"a+");
    fprintf(f,"%d %d %d\n",transceivers,channels,id);
    for (i=0;i<transceivers;i++)
    {
        for (j=0;j<transceivers;j++)
        {
            for (p=0;p<channels;p++)
            {
                for (q=0;q<channels;q++){
                    fprintf(f,"%d, %d, %d, %d, %.4f\n",i,j,p,q,m_w[i][j][p][q]);
                }
            }
        }
    }
    fclose(f);*/
}


/*
 * This function evaluates the individuals for the FAP problem.
 */
float FAP::Evaluate(int * x)
{
    float fitness=0;
    int i,j;
    float interference_factor;
    for (i=0;i<m_size;i++){
        for (j=0;j<m_size;j++){
            interference_factor=m_w[i][j][x[i]][x[j]];
            fitness+=interference_factor;
        }
    }
    return fitness;
}


/*
 * Returns the size of the problem.
 */
int FAP::GetProblemSize()
{
    return m_size;
}


void FAP::Eval_Complete(CIndividual * indiv){
    
    indiv->m_value=Evaluate(indiv->m_genes);
    indiv->m_fc[0]=f2r_basic(indiv->m_genes);
    //indiv->m_fc[1]=fr_basic(indiv->m_genes);
    indiv->m_fc[1]=indiv->m_value-indiv->m_fc[0];
    
}

/*
 * Calculates the fitness value corresponding to the zero component (f_{2r}) of the elementary landscape decomposition.
 */
float FAP::f2r_basic(int * x){
    float f2r=0;
    int i,j,p,q;
    int alpha=m_number_of_channels-2;
    for (i=0;i<m_size;i++){
        
        for (j=0;j<i;j++){
            for (p=0;p<m_number_of_channels;p++)
            {
                for (q=0;q<m_number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        f2r+=(m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        f2r-=m_w[i][j][p][q];
                }
            }
        }
        for (j=i+1;j<m_size;j++){
            for (p=0;p<m_number_of_channels;p++)
            {
                for (q=0;q<m_number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        f2r+=(m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        f2r-=m_w[i][j][p][q];
                }
            }
        }
    }
    f2r=(f2r/(float)m_number_of_channels);
    return f2r;
}

/*
 * Calculates the fitness value corresponding to the zero component (f_{r}) of the elementary landscape decomposition.
 */
float FAP::fr_basic(int * x){
    
    float fr=0;
    int i,j,p,q;
    int alpha=-2;
    
    float second_part=0;
    // first part
    for (i=0;i<m_size;i++){
        second_part+=m_w[i][i][x[i]][x[i]];
        for (j=0;j<i;j++){
            for (p=0;p<m_number_of_channels;p++)
            {
                for (q=0;q<m_number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        fr+=(m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        fr-=m_w[i][j][p][q];
                }
            }
        }
        for (j=i+1;j<m_size;j++){
            for (p=0;p<m_number_of_channels;p++)
            {
                for (q=0;q<m_number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        fr+=(m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        fr-=m_w[i][j][p][q];
                }
            }
        }
    }
    fr=-(fr/(float)m_number_of_channels);
    
    //second part
    //for (i=0;i<m_size;i++){
    //    fr+=m_w[i][i][x[i]][x[i]];
    //}
    fr+=second_part;
    return fr;
}
