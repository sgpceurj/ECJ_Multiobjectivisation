//
//  FAP.hpp
//  NSGA2forFAP
//
//  Created by Josu Ceberio Uribe on 16/02/17.
//  Copyright © 2017 University of the Basque Country. All rights reserved.
//

#ifndef FAP_hpp
#define FAP_hpp

#include "Tools.h"
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string.h>
#include <stdio.h>

using std::ifstream;
using std::ofstream;
using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::stringstream;
using std::string;

class FAP
{
    
public:
    
    /*
     * The matrix of values of the instance.
     */
    float **** m_w;
        
    /*
     * The size of the problem.
     */
    int m_size;
    
    /*
     * The number of channels.
     */
    int m_number_of_channels;
    
    /*
     * The constructor. It initializes a FAP from a file.
     */
    FAP();
    
    /*
     * The destructor.
     */
    virtual ~FAP();
    
    int RandomInstance();
    
    /*
     * Read FAP instance from file.
     */
    int Read(char * instancefile);
    
    /*
     * This function evaluates the individuals for the FAP problem.
     */
    float Evaluate(int * solution);
    
    /*
     * Returns the size of the problem.
     */
    int GetProblemSize();
    
    void Eval_Complete(CIndividual * indiv);
    
    /*
     * Calculates the fitness value corresponding to the zero component (f_{2r}) of the elementary landscape decomposition.
     */
    float f2r_basic(int * x);
    
    
    /*
     * Calculates the fitness value corresponding to the first component (f_{r}) of the elementary landscape decomposition.
     */
    float fr_basic(int * x);
    
    void CreateInstance(int transceivers, int channels, int id);
    
private:
    
};

#endif /* FAP_hpp */
