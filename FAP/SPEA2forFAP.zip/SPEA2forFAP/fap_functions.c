//
//  fap_functions.c
//  SPEA2forFAP
//
//  Created by Josu Ceberio Uribe on 14/03/17.
//  Copyright © 2017 University of the Basque Country. All rights reserved.
//

#include "spea2.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>

using std::ifstream;
using std::ofstream;
using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::stringstream;
using std::string;

fap* read_instance(char * instancefile)
{
    fap* problem;
    problem=(fap*)malloc(sizeof(fap));
    
    FILE* f=fopen(instancefile,"r+");
    if ( f==NULL){
        printf("\n ERROR: unable to read FAP instance file.\n"); exit(1);
    }
    int id;
    int trash,trash1,trash2,trash3;
 
    fscanf(f,"%d %d %d",&problem->size,&problem->number_of_channels,&id);
    int i,j,p,q;
    float weight;
    problem->m_w= new float***[problem->size];
    for (i=0;i<problem->size;i++)
    {
        problem->m_w[i]=new float**[problem->size];
        for (j=0;j<problem->size;j++)
        {
            problem->m_w[i][j]=new float*[problem->number_of_channels];
            for (p=0;p<problem->number_of_channels;p++)
            {
                problem->m_w[i][j][p]=new float[problem->number_of_channels];
                for (q=0;q<problem->number_of_channels;q++){
 
                    fscanf(f,"%d, %d, %d, %d, %f",&trash,&trash1,&trash2,&trash3,&weight);
                    problem->m_w[i][j][p][q]=weight;
                }
            }
        }
 
    }
    problem->best=create_ind(problem->size, 2);
     return problem;

}

fap* random_instance()
{
    fap* problem;
    problem=(fap*)malloc(sizeof(fap));
    
    problem->size=10+(rand()%41); //number of transceivers. Set randomly.
    problem->number_of_channels=1+rand()%(problem->size-1);//number of channels. Set randomly.
#ifdef VERBOSE
    cout<<"#transceivers: "<<problem->size<<"   #channels: "<<problem->number_of_channels<<endl;
#endif
    problem->m_w= new float***[problem->size];
    int i,j,p,q;
    int min=1;
    int max=10;
    for (i=0;i<problem->size;i++)
    {
        problem->m_w[i]=new float**[problem->size];
        for (j=0;j<problem->size;j++)
        {
            problem->m_w[i][j]=new float*[problem->number_of_channels];
            for (p=0;p<problem->number_of_channels;p++)
            {
                problem->m_w[i][j][p]=new float[problem->number_of_channels];
                for (q=0;q<problem->number_of_channels;q++){
                    problem->m_w[i][j][p][q]=(rand()%(max-min))+min;
                }
            }
        }
    }
    /*
     for (i=0;i<m_size;i++)
     {
     for (j=i+1;j<m_size;j++)
     {
     for (p=0;p<m_number_of_channels;p++)
     {
     for (q=p+1;q<m_number_of_channels;q++){
     m_w[j][i][q][p]=m_w[i][j][p][q];
     }
     }
     }
     }*/
    
    problem->best=create_ind(problem->size, 2);
    
    return (problem);
}

/*
 * This function evaluates the individuals for the QAP problem as LOP.
 */
float evaluate(int * x, fap * problem)
{
    int fitness=0;
    int i,j;
    int interference_factor;
    for (i=0;i<problem->size;i++){
        for (j=0;j<problem->size;j++){
            interference_factor=(int)problem->m_w[i][j][x[i]][x[j]];
            fitness+=interference_factor;
        }
    }
    return fitness;
}


void evaluate_optimized(ind * indiv,fap * problem){
    
    indiv->real_fitness=evaluate(indiv->genes,problem);
    indiv->f[0]=f2r_basic(indiv->genes,problem);
    //indiv->m_fc[1]=fr_basic(indiv->m_genes);
    indiv->f[1]=indiv->real_fitness-indiv->f[0];
    //  if (((int)indiv->m_value)!=((int)(indiv->m_fc[0]+indiv->m_fc[1]))){
    //      printf("%.3f, [%.3f,%.3f] ",indiv->m_value,indiv->m_fc[0],indiv->m_fc[1]);
    //      cout<<"NO coincide"<<endl; exit(1);
    //  }
    //indiv->m_fc[1]=indiv->m_fc[0]+indiv->m_value;
}


/*
 * Calculates the fitness value corresponding to the first component of the elementary landscape decomposition.
 */
float f2r_basic(int * x, fap * problem){
    
    float f2r=0;
    int i,j,p,q;
    int alpha=problem->number_of_channels-2;
    for (i=0;i<problem->size;i++){
        
        for (j=0;j<i;j++){
            for (p=0;p<problem->number_of_channels;p++)
            {
                for (q=0;q<problem->number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        f2r+=(problem->m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        f2r-=problem->m_w[i][j][p][q];
                }
            }
        }
        for (j=i+1;j<problem->size;j++){
            for (p=0;p<problem->number_of_channels;p++)
            {
                for (q=0;q<problem->number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        f2r+=(problem->m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        f2r-=problem->m_w[i][j][p][q];
                }
            }
        }
    }
    f2r=(f2r/(float)problem->number_of_channels);
    return f2r;
}

/*
 * Calculates the fitness value corresponding to the second component of the elementary landscape decomposition.
 */
float fr_basic(int * x,fap * problem){
    
    float fr=0;
    int i,j,p,q;
    int alpha=-2;
    
    // first part
    for (i=0;i<problem->size;i++){
        for (j=0;j<i;j++){
            for (p=0;p<problem->number_of_channels;p++)
            {
                for (q=0;q<problem->number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        fr+=(problem->m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        fr-=problem->m_w[i][j][p][q];
                }
            }
        }
        for (j=i+1;j<problem->size;j++){
            for (p=0;p<problem->number_of_channels;p++)
            {
                for (q=0;q<problem->number_of_channels;q++){
                    if (x[i]==p && x[j]==q)
                        fr+=(problem->m_w[i][j][p][q]*alpha);
                    else if (x[i]==p || x[j]==q)
                        fr-=problem->m_w[i][j][p][q];
                }
            }
        }
    }
    fr=-(fr/(float)problem->number_of_channels);
    
    //second part
    for (i=0;i<problem->size;i++){
        fr+=problem->m_w[i][i][x[i]][x[i]];
    }
    return fr;
}


void printMatrix(int** matrix, int length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }
}

void printArray(int* array, int size)/* Prints in standard output 'length' double elements of a given array. */
{
    for (int i=0;i<size;i++){
        printf(" %d,",array[i]);
    }
    printf("\n ");
}

/*
 * Generates a random sequence solution of size 'n' in the given array.
 */
void GenerateRandomSequence(int * solution, int transceivers, int channels)
{
    for (int i=0;i<transceivers;i++){
        solution[i]= rand()%channels;
    }
}

void initialize_pop(pop * population,fap * problem){
    int i;
    for (i=0;i<population->size;i++)
    {
        GenerateRandomSequence(population->ind_array[i]->genes,population->ind_array[i]->size,problem->number_of_channels);
    }
}

void evaluate_pop(pop * population, fap * problem){
    int i;
    int i_best=-1;
    for (i=0;i<population->size;i++)
    {
        evaluate_optimized(population->ind_array[i], problem);
               
        //population->ind_array[i]->real_fitness=evaluate(population->ind_array[i]->genes, problem);
        //population->ind_array[i]->f[0]=problem->m_f0;
        //population->ind_array[i]->f[1]=f2_basic(population->ind_array[i]->genes, problem);
        //population->ind_array[i]->f[2]=f4_basic(population->ind_array[i]->genes, problem);
        //population->ind_array[i]->f[2]=population->ind_array[i]->real_fitness-problem->m_f0-population->ind_array[i]->f[1];
        
        problem->evaluations++;
        if ( (i_best==-1 && problem->best->real_fitness>population->ind_array[i]->real_fitness) || (i_best!=-1 && population->ind_array[i_best]->real_fitness>population->ind_array[i]->real_fitness)){
            i_best=i;
        }
    }
    if (i_best!=-1){
        memcpy(problem->best->f, population->ind_array[i_best]->f, sizeof(float)*2);
        problem->best->real_fitness=population->ind_array[i_best]->real_fitness;
        problem->best->fitness=population->ind_array[i_best]->fitness;
        problem->best->size=population->ind_array[i_best]->size;
        memcpy(problem->best->genes, population->ind_array[i_best]->genes, sizeof(int)*problem->best->size);
#ifdef VERBOSE
        printf("Best: %g  evals: %ld, f: %.5f, %.5f\n ", problem->best->real_fitness, problem->evaluations, problem->best->f[0], problem->best->f[1]);
#endif
    }
    
}

ind* binary_tournament (ind * indiv1, ind * indiv2){ //checks which of the individuals is fitter.
    
    if (dominates(indiv1,indiv2)){
        //    if (indiv1->f[1]<indiv2->f[1] && indiv1->f[2]<indiv2->f[2]){
        return (indiv1);
    }
    if (dominates(indiv2,indiv1)){
        //    if (indiv1->f[1]>indiv2->f[1] && indiv1->f[2]>indiv2->f[2]){
        return (indiv2);
    }
    if (indiv1->real_fitness<indiv2->real_fitness){
        return (indiv1);
    }
    if (indiv1->real_fitness>indiv2->real_fitness){
        return (indiv2);
    }
    if ((rand()/RAND_MAX) <= 0.5)
    {
        return(indiv1);
    }
    else
    {
        return(indiv2);
    }
}

void crossoverOPX (ind * parent1, ind * parent2, ind * child1, ind * child2 ){
    
    int i;
    int size=parent1->size;
    std::vector<int> non_used_parent1; int index_non_used1=0;
    std::vector<int> non_used_parent2; int index_non_used2=0;
    int element1,element2;
    for (i=0;i<size;i++) {
        element1=parent1->genes[i];
        element2=parent2->genes[i];
        if (EQUAL(element1, element2)==0){
            child1->genes[i]=-1;
            child2->genes[i]=-1;
            non_used_parent1.push_back(element1);
            non_used_parent2.push_back(element2);
        }
        else{
            child1->genes[i]=element1;
            child2->genes[i]=element2;
        }
    }
    
    int crossover_point= (rand()% (size-2));
    memcpy(child1->genes, parent1->genes, sizeof(int)*(crossover_point+1));
    memcpy(child2->genes, parent2->genes, sizeof(int)*(crossover_point+1));
    
    for (i=0;i<=crossover_point;i++){
        remove(&non_used_parent2, parent1->genes[i]);
        remove(&non_used_parent1, parent2->genes[i]);
    }
    
    for (i=crossover_point+1;i<size;i++){
        if (child1->genes[i]==-1){
            child1->genes[i]=non_used_parent2.at(index_non_used2);
            index_non_used2++;
        }
        if (child2->genes[i]==-1){
            child2->genes[i]=non_used_parent1.at(index_non_used1);
            index_non_used1++;
        }
    }
    non_used_parent1.clear();
    non_used_parent2.clear();
}



/*
 * Crossover operator. OPX
 */
void Crossover_OPX (ind * parent1, ind * parent2, ind * child1, ind * child2 ){
    
    int i;
    int crossover_point= (rand()% (parent1->size-1));
    memcpy(child1->genes, parent1->genes, sizeof(int)*(crossover_point));
    memcpy(child2->genes, parent2->genes, sizeof(int)*(crossover_point));
    
    for (i=crossover_point;i<parent1->size;i++){
        child1->genes[i]=parent2->genes[i];
        child2->genes[i]=parent1->genes[i];
    }
}


void mutateSwap(int * genes, int size){
    int i=rand()% size;
    int j=rand()% size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}


/*
 * Mutates the individual applying the interchange mutation operator.
 */
void Mutate_Interchange(int * genes, int size){
    int i=rand()% size;
    int j=rand()% size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}

/*
 * Mutates the individual applying the reverse mutation operator.
 */
void Mutate_TwoTRX(int * genes, int size, int num_channels){
    int i=rand()% size;
    int j=rand()% size;
    genes[i]=rand()%num_channels;
    genes[j]=rand()%num_channels;
}


bool remove(std::vector<int> * v, int element){
    
    for (int i=0;i<v->size();i++){
        if (element==v->at(i)){
            v->erase(v->begin()+i);
            return true;
        }
    }
    return false;
}

