//
//  qap_functions.cpp
//  SPEA2
//
//  Created by Josu Ceberio Uribe on 23/12/15.
//  Copyright © 2015 University of the Basque Country. All rights reserved.
//

#include "spea2.h"
#include <stdio.h>
#include <assert.h>
#include <vector>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>

using std::ifstream;
using std::ofstream;
using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::stringstream;
using std::string;

qap* read_instance(char * instancefile)
{
    qap* problem;
    problem=(qap*)malloc(sizeof(qap));
    
    FILE* fp = fopen(instancefile, "r");
    assert(fp != NULL);
    int size,value,i,j;
    fscanf(fp, "%d",&size); /* read size */
    
    
    //printf("Initializing... %d\n ",size);
    /* initialize qap structure */
    problem->best=create_ind(size, 3);
    problem->size=size;
    problem->evaluations=0;
    problem->fc_avg=(double*)malloc(3*sizeof(double));
    problem->distance_matrix=(int**)malloc(size*sizeof(int*));
    problem->flow_matrix=(int**)malloc(size*sizeof(int*));
    for (i=0;i<size;i++){
        problem->distance_matrix[i]=(int*)malloc(size*sizeof(int));
        problem->flow_matrix[i]=(int*)malloc(size*sizeof(int));
    }
    
   // printf("distance...\n");
    /* read distance matrix */
    for (i=0;i<size;i++){
        for (j=0;j<size;j++){
            fscanf(fp,"%d",&value);
            problem->distance_matrix[i][j]=value;
        //    printf("%d ",problem->distance_matrix[i][j]);
        }
       // printf("\n");
    }
    
    //printf("flow...\n");
    /* read distance matrix */
    for (i=0;i<size;i++){
        for (j=0;j<size;j++){
            fscanf(fp,"%d",&value);
            problem->flow_matrix[i][j]=value;
            //printf("%d ",problem->flow_matrix[i][j]);
            
        }
        //printf("\n");
    }
    //PrintMatrix(problem->flow_matrix, size, size);
    calculateAverageComponents(problem);
    return (problem);
}

qap* read_instance2(char * instancefile)
{
    qap* problem;
    problem=(qap*)malloc(sizeof(qap));
    int size=0,i, distance,weight;
    char line[5096]; // variable for input value
    ifstream indata;
    indata.open(instancefile,ios::in);
    int num=0;
      char * pch;
    while (!indata.eof())
    {
        //LEER LA LINEA DEL FICHERO
        indata.getline(line, 5096);
        stringstream ss;
        string sline;
        ss << line;
        ss >> sline;
        //cout<<"line: "<<line<<endl;
        if (num==0)
        {
            //OBTENER EL TAMAÑO DEL PROBLEMA
            size = atoi(sline.c_str());
            problem->best=create_ind(size, 3);
            problem->size=size;
            problem->evaluations=0;
            problem->fc_avg=(double*)malloc(3*sizeof(double));
            problem->distance_matrix=(int**)malloc(size*sizeof(int*));
            problem->flow_matrix=(int**)malloc(size*sizeof(int*));
            for (i=0;i<size;i++){
                problem->distance_matrix[i]=(int*)malloc(size*sizeof(int));
                problem->flow_matrix[i]=(int*)malloc(size*sizeof(int));
            }

        }
        else if (1<=num && num<=size)
        {
            //LOAD DISTANCE MATRIX
            pch = strtok (line," ");
            distance=atoi(pch);
            problem->distance_matrix[num-1][0]=distance;
            for (i=1;i < size; i++)
            {
                pch = strtok (NULL, " ,.");
                distance=atoi(pch);
                problem->distance_matrix[num-1][i]=distance;
            }
        }
        else if (num>size && num<=(2*size))
        {
            //LOAD FLOW MATRIX
            pch = strtok (line," ");
            weight=atoi(pch);
            problem->flow_matrix[num-size-1][0]=weight;
            for (i=1;i < size; i++)
            {
                pch = strtok (NULL, " ,.");
                weight=atoi(pch);
                problem->flow_matrix[num-size-1][i]=weight;
            }
        }
        else
        {
            break;
        }
        
        num++;
    }
    
    indata.close();
    
    calculateAverageComponents(problem);
    // is fc1 constant?
    int j;
    bool symetric=true;
    for (i=0;i<size-1 && symetric;i++){
        for (j=i;j<size && symetric;j++){
            if (problem->distance_matrix[i][j]!=problem->distance_matrix[j][i]){// || problem->flow_matrix[i][j]!=problem->flow_matrix[j][i]){
                symetric=false;
                //cout<<" dist(i,j): "<<m_distance_matrix[i][j]<< " dist(j,i): "<<m_distance_matrix[j][i]<<" flow(i,j): "<<m_flow_matrix[i][j]<< " flow(j,i): "<<m_flow_matrix[j][i]<<endl;
            }
        }
    }
    
    if (symetric){
        problem->m_fc1_constant=1;
        cout<<"Fc1 is constant"<<endl;
    }
    else{
        problem->m_fc1_constant=0;
        cout<<"Fc1 is NOT constant"<<endl;
    }
    //delete [] genes;
    return (problem);
}

double evaluate(int * genes, qap * problem)
{
    double fitness=0;
    int FactA, FactB;
    int distAB, flowAB, i ,j;
    for (i=0;i<problem->size;i++)
    {
        for (j=0;j<problem->size;j++)
        {
            FactA = genes[i];
            FactB = genes[j];
            
            distAB= problem->distance_matrix[i][j];
            flowAB= problem->flow_matrix[FactA][FactB];
            fitness= fitness+(distAB*flowAB);			
        }
    }
    return fitness;
}

/*
 * Omega 1.
 */
inline int Omega1(int i, int j, int p, int q, int * x, int n){
    if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
        return -1; //rho
    if ((x[i]==p)^(x[j]==q))
        return -2; //gamma
    if ((x[i]==q)^(x[j]==p))
        return 0; //epsilon
    if ((x[i]==p)&&(x[j]==q))
        return n-3; //alpha.
    if ((x[i]==q)&&(x[j]==p))
        return 1-n; //beta
    cout<<"Error in Omega 1. "<<endl; exit(1);
}

/*
 * Calculates the fitness value corresponding to the first component of the elementary landscape decomposition. This method is optimized for a more efficient computation.
 */
double evaluate_fc1(int * x, qap * problem){
    int i,j,p,q;
    double result=0;
    int n=problem->size;
    for (i=0;i<n;i++){
        for (j=0;j<n;j++){
            for (p=0;p<n;p++){
                for (q=0;q<n;q++){
                    if (i!=j && p!=q)
                        result+=(double)(Omega1(i,j,p,q, x,n)*problem->distance_matrix[i][j]*problem->flow_matrix[p][q]);
                }
            }
        }
    }
    result=result/(double)(2*problem->size);
    return result;
}

/*
 * Calculates the fitness value corresponding to the third component of the elementary landscape decomposition. This method is optimized for a more efficient computation.
 */
double evaluate_fc3(int * x, qap * problem){
        int i,j,p,q;
        double result=0;
        int n=problem->size;
        double psi;
        for (i=0;i<n;i++){
            for (j=i+1;j<n;j++){
                for (p=0;p<n;p++){
                    
                    for (q=0;q<p;q++){
                        psi=2*problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                        if ((x[i]==p)^(x[j]==q))
                            result+= (n-2)* psi; //gamma Omega3
                        else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
                            result-= psi; //zeta Omega3
                        else if ((x[i]==p)&&(x[j]==q))
                            result+=(2*n-3)*psi; //alpha Omega3
                        else if ((x[i]==q)&&(x[j]==p))
                            result+= psi; //beta Omega3
                    }
                    
                    for (q=p+1;q<n;q++){
                        psi=2*problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                        if ((x[i]==p)^(x[j]==q))
                            result+= (n-2)* psi; //gamma Omega3
                        else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q)
                            result-= psi; //zeta Omega3
                        else if ((x[i]==p)&&(x[j]==q))
                            result+=(2*n-3)*psi; //alpha Omega3
                        else if ((x[i]==q)&&(x[j]==p))
                            result+= psi; //beta Omega3
                    }
                }
            }
        }
        result=result/(double)(problem->size*(problem->size-2));
        
        return result;
}
/*
 * Calculates the fitness value corresponding to the second component of the elementary landscape decomposition. This method is optimized for a more efficient computation.
 */
double evaluate_fc2(int * x, qap * problem){
    int i,j,p,q;
    long int result=0;
    long int aux;
    int size=problem->size;
    int n3=size-3;
    int min,max;//,min_plus,max_plus;
    for (i=0;i<size;i++){
        for (j=i+1;j<size;j++){
            
            min=MIN(x[i],x[j]);
            max=MAX(x[i],x[j]);
            
            aux=problem->totalpq;
            
            //p==min denenan,
            p=min;
            for (q=0;q<min;q++)
                aux -= problem->flow_matrix[p][q];
            for (q=min+1;q<size;q++)
                aux -= problem->flow_matrix[p][q];
            
            //p==max denenan,
            p=max;
            for (q=0;q<max;q++)
                aux -= problem->flow_matrix[p][q];
            for (q=max+1;q<size;q++)
                aux -= problem->flow_matrix[p][q];
            
            //eta q-rekin berdin:
            
            //q==min denenan,
            q=min;
            for (p=0;p<min;p++)
                aux -= problem->flow_matrix[p][q];
            for (p=min+1;p<max;p++)		//--> p==max aurreko pausuan kendu dugu
                aux -= problem->flow_matrix[p][q];
            for (p=max+1;p<size;p++)
                aux -= problem->flow_matrix[p][q];
            
            //q==max denenan,
            q=max;
            for (p=0;p<min;p++)
                aux -= problem->flow_matrix[p][q];
            for (p=min+1;p<max;p++)		//--> p==max aurreko pausuan kendu dugu
                aux -= problem->flow_matrix[p][q];
            for (p=max+1;p<size;p++)
                aux -= problem->flow_matrix[p][q];
            
            //alpha case
            aux+=n3*problem->flow_matrix[x[i]][x[j]];
            
            //beta case.
            aux+=n3*problem->flow_matrix[x[j]][x[i]];
            
            //we multiply with distance here because the distance is a common factor in the calculation.
            result+=aux*problem->distance_matrix[i][j];
        }
    }
    //result=result/(double)(2*(m_size-2));
    return (double)result/(double)(size-2);
}

/*
 * Calculates the fitness value decomposed in the three components of the elementary landscape decomposition.
 */
void evaluate_f_components(int * x, double * components, qap * problem){
    int i,j,p,q;
    double psi;
    double result1=0, result2=0;//, result3=0;
    int n=problem->size;
    int n_3=n-3;
    for (i=0;i<n;i++){
        for (j=0;j<i;j++){
            for (p=0;p<n;p++){
                for (q=0;q<p;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                }
                for (q=p+1;q<n;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                    
                }
            }
        }
        for (j=i+1;j<n;j++){
            for (p=0;p<n;p++){
                for (q=0;q<p;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                }
                for (q=p+1;q<n;q++){
                    psi=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                    if ((x[i]==p)^(x[j]==q)){
                        result1-=2*psi; //gamma Omega1
                        //    result2+=(0)*psi; //gamma Omega2
                        //result3+= (n-2)* psi; //gamma Omega3
                    }
                    else if (x[i]!=p && x[i]!=q && x[j]!=p && x[j]!=q){
                        result1-= psi; //zeta Omega1
                        result2+= psi; //zeta Omega2
                        //result3-= psi; //zeta Omega3
                    }
                    //else if ((x[i]==q)^(x[j]==p))
                    //  result1+=0; //epsilon is always 0
                    //  result2+=0; //epsilon is always 0
                    //  result3+=0; //epsilon is always 0
                    else if ((x[i]==p)&&(x[j]==q)){
                        result1+=n_3*psi; //alpha Omega1
                        result2+=n_3*psi; //alpha Omega2
                        //result3+=(2*n-3)*psi; //alpha Omega3
                    }
                    else if ((x[i]==q)&&(x[j]==p)){
                        result1+=(1-n)*psi; //beta Omega1
                        result2+=n_3*psi; //beta Omega2
                        //result3+= psi; //beta Omega3
                    }
                    
                }
            }
        }
    }
    components[0]=result1/(double)(2*n);
    components[1]=result2/(double)(2*(n-2));
    // components[2]=result3/(double)(n*(n-2));
}

/*
 * Calculates the average fitness components of the elementary landscape decomposition needed to calculate the average
 * fitness of a neighborhood in close form.
 */
void calculateAverageComponents(qap * problem){
    double phi=0;
    int i,j,p,q;
    int size= problem->size;
    for (i=0;i<size;i++){
        for (j=0;j<size;j++){
            for (p=0;p<size;p++){
                for (q=0;q<size;q++){
                    if (i!=j && p!=q)
                        phi+=problem->distance_matrix[i][j]*problem->flow_matrix[p][q];
                }
            }
        }
    }
    problem->fc_avg[0]=- phi/(double)(2*size);
    problem->fc_avg[1]= phi * (size-3)/(double)(2*(size-2)*(size-1));
    problem->fc_avg[2]= phi/(double)(size*(size-2));
    
    problem->totalpq=0;
    for (p=0;p<size;p++){
        for (q=0;q<p;q++)
            problem->totalpq += problem->flow_matrix[p][q];
        for (q=p+1;q<size;q++)
            problem->totalpq += problem->flow_matrix[p][q];
    }
    //printf("%f, %f, %f, %ld\n",problem->fc_avg[0],problem->fc_avg[1],problem->fc_avg[2],problem->totalpq);
}

void printMatrix(int** matrix, int length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }
}

void printArray(int* array, int size)/* Prints in standard output 'length' double elements of a given array. */
{
    for (int i=0;i<size;i++){
        printf(" %d,",array[i]);
    }
    printf("\n ");
}

/*
 * Generates a random permutation of size 'n' in the given array.
 */
void generate_RandomPermutation(int * permutation, int n)
{
    int i,j;
    for (i = 0; i < n; i++)
    {
        j = rand() % (i + 1);
        permutation[i] = permutation[j];
        permutation[j] = i;
    }
}

void initialize_pop(pop * population){
    int i;
    for (i=0;i<population->size;i++)
    {
        generate_RandomPermutation(population->ind_array[i]->genes,population->ind_array[i]->size);
    }
}

void evaluate_pop(pop * population, qap * problem){
    int i;
    double f,fc2;
    int i_best=-1;
    for (i=0;i<population->size;i++)
    {
        f=evaluate(population->ind_array[i]->genes, problem);
        population->ind_array[i]->real_fitness=f;
        
        if (problem->m_fc1_constant==1)
        {
            fc2=evaluate_fc2(population->ind_array[i]->genes, problem);
            population->ind_array[i]->f[1]=fc2;
            population->ind_array[i]->f[0]=problem->fc_avg[0];
            population->ind_array[i]->f[2]=f-(problem->fc_avg[0]+fc2);
        }
        else{
            evaluate_f_components(population->ind_array[i]->genes,population->ind_array[i]->f,problem);
            population->ind_array[i]->f[2]=f-population->ind_array[i]->f[0]-population->ind_array[i]->f[1];
        }
        
 
        problem->evaluations++;
        if (problem->best->real_fitness>f){
            i_best=i;
        }
    }
    if (i_best!=-1){
        memcpy(problem->best->f, population->ind_array[i_best]->f, sizeof(double)*3);
        problem->best->real_fitness=population->ind_array[i_best]->real_fitness;
        problem->best->fitness=population->ind_array[i_best]->fitness;
        problem->best->size=population->ind_array[i_best]->size;
        memcpy(problem->best->genes, population->ind_array[i_best]->genes, sizeof(int)*problem->best->size);
#ifdef VERBOSE
        printf("Best: %g  evals: %ld, f: %.5f, %.5f, %.5f\n ", problem->best->real_fitness, problem->evaluations, problem->best->f[0], problem->best->f[1], problem->best->f[2]);
#endif
    }
    
}

ind* binary_tournament (ind * indiv1, ind * indiv2){ //checks which of the individuals is fitter.
    
    if (dominates(indiv1,indiv2)){
//    if (indiv1->f[1]<indiv2->f[1] && indiv1->f[2]<indiv2->f[2]){
        return (indiv1);
    }
    if (dominates(indiv2,indiv1)){
//    if (indiv1->f[1]>indiv2->f[1] && indiv1->f[2]>indiv2->f[2]){
        return (indiv2);
    }
    if (indiv1->real_fitness<indiv2->real_fitness){
        return (indiv1);
    }
    if (indiv1->real_fitness>indiv2->real_fitness){
        return (indiv2);
    }
    if ((rand()/RAND_MAX) <= 0.5)
    {
        return(indiv1);
    }
    else
    {
        return(indiv2);
    }
}

void crossoverOPX (ind * parent1, ind * parent2, ind * child1, ind * child2 ){
    
    int i;
    int size=parent1->size;
    std::vector<int> non_used_parent1; int index_non_used1=0;
     std::vector<int> non_used_parent2; int index_non_used2=0;
    int element1,element2;
    for (i=0;i<size;i++) {
        element1=parent1->genes[i];
        element2=parent2->genes[i];
        if (EQUAL(element1, element2)==0){
            child1->genes[i]=-1;
            child2->genes[i]=-1;
            non_used_parent1.push_back(element1);
            non_used_parent2.push_back(element2);
        }
        else{
            child1->genes[i]=element1;
            child2->genes[i]=element2;
        }
    }
    
    int crossover_point= (rand()% (size-2));
    memcpy(child1->genes, parent1->genes, sizeof(int)*(crossover_point+1));
    memcpy(child2->genes, parent2->genes, sizeof(int)*(crossover_point+1));
    
    for (i=0;i<=crossover_point;i++){
        remove(&non_used_parent2, parent1->genes[i]);
        remove(&non_used_parent1, parent2->genes[i]);
    }
    
    for (i=crossover_point+1;i<size;i++){
        if (child1->genes[i]==-1){
            child1->genes[i]=non_used_parent2.at(index_non_used2);
            index_non_used2++;
        }
        if (child2->genes[i]==-1){
            child2->genes[i]=non_used_parent1.at(index_non_used1);
            index_non_used1++;
        }
    }
    non_used_parent1.clear();
    non_used_parent2.clear();
}

void mutateSwap(int * genes, int size){
    int i=rand()% size;
    int j=rand()% size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}

bool remove(std::vector<int> * v, int element){
    
    for (int i=0;i<v->size();i++){
        if (element==v->at(i)){
            v->erase(v->begin()+i);
            return true;
        }
    }
    return false;
}

