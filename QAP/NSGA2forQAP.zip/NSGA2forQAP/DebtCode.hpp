//
//  DebtCode.hpp
//  NSGA2forQAP
//
//  Created by Josu Ceberio Uribe on 04/05/16.
//  Copyright © 2016 Josu Ceberio Uribe. All rights reserved.
//

#ifndef DebtCode_hpp
#define DebtCode_hpp
#include "Population.h"
#include <stdio.h>

bool Fast_NonDominatedSorting_Original ( CPopulation * mixed_pop, CPopulation *  parent_pop, CIndividual * best, bool fc1_constant);
void crowding_fill (CPopulation *mixed_pop, CPopulation *new_pop, int count, int front_size, list *elite);

void assign_rank_and_crowding_distance (CPopulation *new_pop, CIndividual * best, bool fc1_constant);
void assign_crowding_distance (CPopulation *pop, int *dist, int **obj_array, int front_size);
void assign_crowding_distance_indices (CPopulation *pop, int c1, int c2);
void assign_crowding_distance_list (CPopulation *pop, list *lst, int front_size);

void q_sort_front_obj(CPopulation *pop, int objcount, int obj_array[], int left, int right);
void q_sort_dist(CPopulation *pop, int *dist, int left, int right);

void insert (list *node, int x);
list* del (list *node);

#endif /* DebtCode_hpp */
