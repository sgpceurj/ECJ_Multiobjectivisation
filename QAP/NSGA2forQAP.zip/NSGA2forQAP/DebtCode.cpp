//
//  DebtCode.cpp
//  NSGA2forQAP
//
//  Created by Josu Ceberio Uribe on 04/05/16.
//  Copyright © 2016 Josu Ceberio Uribe. All rights reserved.
//

#include "DebtCode.hpp"

bool Fast_NonDominatedSorting_Original ( CPopulation * mixed_pop, CPopulation *  new_pop, CIndividual * best, bool fc1_constant){
    
    int flag;
    int i, j;
    int end;
    int front_size;
    int archieve_size;
    int rank=1;
    list *pool;
    list *elite;
    list *temp1, *temp2;
    pool = (list *)malloc(sizeof(list));
    elite = (list *)malloc(sizeof(list));
    front_size = 0;
    archieve_size=0;
    pool->index = -1;
    pool->parent = NULL;
    pool->child = NULL;
    elite->index = -1;
    elite->parent = NULL;
    elite->child = NULL;
    temp1 = pool;
    bool improved=false;
    int popsize= new_pop->m_pop_size;
    for (i=0; i<mixed_pop->m_pop_size; i++)
    {
        insert (temp1,i);
        temp1 = temp1->child;
        if(best->m_value>mixed_pop->m_individuals[i]->m_value){
            improved=true;
            Copy_Ind(mixed_pop->m_individuals[i], best);
        }
    }
    i=0;
    do
    {
        temp1 = pool->child;
        insert (elite, temp1->index);
        front_size = 1;
        temp2 = elite->child;
        temp1 = del (temp1);
        temp1 = temp1->child;
        do
        {
            temp2 = elite->child;
            if (temp1==NULL)
            {
                break;
            }
            do
            {
                end = 0;
                flag = Dominates((mixed_pop->m_individuals[temp1->index]), (mixed_pop->m_individuals[temp2->index]),fc1_constant);
                if (flag == 0)
                {
                    insert (pool, temp2->index);
                    temp2 = del (temp2);
                    front_size--;
                    temp2 = temp2->child;
                }
                if (flag == 2)
                {
                    temp2 = temp2->child;
                }
                if (flag == 1)
                {
                    end = 1;
                }
            }
            while (end!=1 && temp2!=NULL);
            if (flag == 0 || flag == 2)
            {
                insert (elite, temp1->index);
                front_size++;
                temp1 = del (temp1);
            }
            temp1 = temp1->child;
        }
        while (temp1 != NULL);
        temp2 = elite->child;
        j=i;
        if ( (archieve_size+front_size) <= popsize)
        {
            do
            {
                Copy_Ind (mixed_pop->m_individuals[temp2->index], new_pop->m_individuals[i]);
                new_pop->m_individuals[i]->m_rank = rank;
                archieve_size+=1;
                temp2 = temp2->child;
                i+=1;
            }
            while (temp2 != NULL);
            assign_crowding_distance_indices (new_pop, j, i-1);
            rank+=1;
        }
        else
        {
            crowding_fill (mixed_pop, new_pop, i, front_size, elite);
            archieve_size = popsize;
            for (j=i; j<popsize; j++)
            {
                new_pop->m_individuals[j]->m_rank = rank;
            }
        }
        temp2 = elite->child;
        do
        {
            temp2 = del (temp2);
            temp2 = temp2->child;
        }
        while (elite->child !=NULL);
    }
    while (archieve_size < popsize);
    while (pool!=NULL)
    {
        temp1 = pool;
        pool = pool->child;
        free (temp1);
    }
    while (elite!=NULL)
    {
        temp1 = elite;
        elite = elite->child;
        free (temp1);
    }
    return improved;
}

/* Routine to fill a population with individuals in the decreasing order of crowding distance */
void crowding_fill (CPopulation *mixed_pop, CPopulation *new_pop, int count, int front_size, list *elite)
{
    int *dist = new int[front_size];
    list *temp;
    int i, j;
    assign_crowding_distance_list (mixed_pop, elite->child, front_size);
    temp = elite->child;
    for (j=0; j<front_size; j++)
    {
        dist[j] = temp->index;
        temp = temp->child;
    }
    q_sort_dist (mixed_pop, dist, 0, front_size-1);
    for (i=count, j=front_size-1; i<new_pop->m_pop_size; i++, j--)
    {
        Copy_Ind(mixed_pop->m_individuals[dist[j]], new_pop->m_individuals[i]);
    }
    delete [] dist;

}

/* Routine to compute crowding distance based on objective function values when the population in in the form of an array */
void assign_crowding_distance_indices (CPopulation *pop, int c1, int c2)
{
    int front_size;
    front_size = c2-c1+1;
    if (front_size==1)
    {
        pop->m_individuals[c1]->m_crowd_dist = MAX_INTEGER;
        return;
    }
    else if (front_size==2)
    {
        pop->m_individuals[c1]->m_crowd_dist = MAX_INTEGER;
        pop->m_individuals[c2]->m_crowd_dist = MAX_INTEGER;
        return;
    }
    else{
        int nobj=3;
        int **obj_array= new int*[nobj];
        int *dist=new int[front_size];
        int i, j;
        for (i=1; i<nobj; i++)
        {
            obj_array[i]= new int[front_size];
        }
        for (j=0; j<front_size; j++)
        {
            dist[j] = c1++;
        }
        assign_crowding_distance (pop, dist, obj_array, front_size);
        delete [] dist;
        
        for (i=1; i<nobj; i++)
        {
            delete [] obj_array[i];
        }
        delete [] obj_array;
    }
}

/* Routine to compute crowding distance based on ojbective function values when the population in in the form of a list */
void assign_crowding_distance_list (CPopulation *pop, list *lst, int front_size)
{
    if (front_size==1)
    {
        pop->m_individuals[lst->index]->m_crowd_dist = MAX_INTEGER;
    }
    else if (front_size==2)
    {
        pop->m_individuals[lst->index]->m_crowd_dist = MAX_INTEGER;
        pop->m_individuals[lst->child->index]->m_crowd_dist = MAX_INTEGER;
    }
    else{
        int nobj=3;
        int **obj_array = new int*[nobj];
        int * dist = new int[front_size];
        list *temp;
        temp = lst;

        int i, j;
        for (i=1; i<nobj; i++)
        {
            obj_array[i] = (int *)malloc(front_size*sizeof(int));
        }
        for (j=0; j<front_size; j++)
        {
            dist[j] = temp->index;
            temp = temp->child;
        }
        assign_crowding_distance (pop, dist, obj_array, front_size);
    
        delete [] dist;
        for (i=1; i<nobj; i++)
        {
            delete [] obj_array[i];
        }
        delete [] obj_array;
    }
}

/* Routine to compute crowding distances */
void assign_crowding_distance (CPopulation *pop, int *dist, int **obj_array, int front_size)
{
    int i, j;
    int nobj=3;
    for (i=1; i<nobj; i++)
    {
        for (j=0; j<front_size; j++)
        {
            obj_array[i][j] = dist[j];
        }
        q_sort_front_obj (pop, i, obj_array[i], 0, front_size-1);
    }
    for (j=0; j<front_size; j++)
    {
        pop->m_individuals[dist[j]]->m_crowd_dist = 0.0;
    }
    for (i=1; i<nobj; i++)
    {
        pop->m_individuals[obj_array[i][0]]->m_crowd_dist = MAX_INTEGER;
    }
    for (i=1; i<nobj; i++)
    {
        for (j=1; j<front_size-1; j++)
        {
            if (pop->m_individuals[obj_array[i][j]]->m_crowd_dist != MAX_INTEGER)
            {
                if (pop->m_individuals[obj_array[i][front_size-1]]->m_fc[i] == pop->m_individuals[obj_array[i][0]]->m_fc[i])
                {
                    pop->m_individuals[obj_array[i][j]]->m_crowd_dist += 0.0;
                }
                else
                {
                    pop->m_individuals[obj_array[i][j]]->m_crowd_dist += (pop->m_individuals[obj_array[i][j+1]]->m_fc[i] - pop->m_individuals[obj_array[i][j-1]]->m_fc[i])/(pop->m_individuals[obj_array[i][front_size-1]]->m_fc[i] - pop->m_individuals[obj_array[i][0]]->m_fc[i]);
                }
            }
        }
    }
    for (j=0; j<front_size; j++)
    {
        if (pop->m_individuals[dist[j]]->m_crowd_dist != MAX_INTEGER)
        {
            pop->m_individuals[dist[j]]->m_crowd_dist = (pop->m_individuals[dist[j]]->m_crowd_dist)/nobj;
        }
    }
}

/* Actual implementation of the randomized quick sort used to sort a population based on a particular objective chosen */
void q_sort_front_obj(CPopulation *pop, int objcount, int obj_array[], int left, int right)
{
    int index;
    int temp;
    int i, j;
    double pivot;
    if (left<right)
    {
        index = left + (rand() % (right-left+1)); //comprobar esta linea
        temp = obj_array[right];
        obj_array[right] = obj_array[index];
        obj_array[index] = temp;
        pivot = pop->m_individuals[obj_array[right]]->m_fc[objcount];
        i = left-1;
        for (j=left; j<right; j++)
        {
            if (pop->m_individuals[obj_array[j]]->m_fc[objcount] <= pivot)
            {
                i+=1;
                temp = obj_array[j];
                obj_array[j] = obj_array[i];
                obj_array[i] = temp;
            }
        }
        index=i+1;
        temp = obj_array[index];
        obj_array[index] = obj_array[right];
        obj_array[right] = temp;
        q_sort_front_obj (pop, objcount, obj_array, left, index-1);
        q_sort_front_obj (pop, objcount, obj_array, index+1, right);
    }
}

/* Actual implementation of the randomized quick sort used to sort a population based on crowding distance */
void q_sort_dist(CPopulation *pop, int *dist, int left, int right)
{
    int index;
    int temp;
    int i, j;
    double pivot;
    if (left<right)
    {
        index = left + (rand() % (right-left+1)); //comprobar esta linea
        temp = dist[right];
        dist[right] = dist[index];
        dist[index] = temp;
        pivot = pop->m_individuals[dist[right]]->m_crowd_dist;
        i = left-1;
        for (j=left; j<right; j++)
        {
            if (pop->m_individuals[dist[j]]->m_crowd_dist <= pivot)
            {
                i+=1;
                temp = dist[j];
                dist[j] = dist[i];
                dist[i] = temp;
            }
        }
        index=i+1;
        temp = dist[index];
        dist[index] = dist[right];
        dist[right] = temp;
        q_sort_dist (pop, dist, left, index-1);
        q_sort_dist (pop, dist, index+1, right);
    }
}

/* Function to assign rank and crowding distance to a population of size pop_size*/
void assign_rank_and_crowding_distance (CPopulation *new_pop, CIndividual * best, bool fc1_constant)
{
    int flag;
    int i;
    int end;
    int front_size;
    int rank=1;
    list *orig;
    list *cur;
    list *temp1, *temp2;
    orig = (list *)malloc(sizeof(list));
    cur = (list *)malloc(sizeof(list));
    front_size = 0;
    orig->index = -1;
    orig->parent = NULL;
    orig->child = NULL;
    cur->index = -1;
    cur->parent = NULL;
    cur->child = NULL;
    temp1 = orig;
    for (i=0; i<new_pop->m_pop_size; i++)
    {
        insert (temp1,i);
        temp1 = temp1->child;
        if(best->m_value>new_pop->m_individuals[i]->m_value){
            Copy_Ind(new_pop->m_individuals[i], best);
        }
    }
    do
    {
        if (orig->child->child == NULL)
        {
            new_pop->m_individuals[orig->child->index]->m_rank = rank;
            new_pop->m_individuals[orig->child->index]->m_crowd_dist = MAX_INTEGER;
            break;
        }
        temp1 = orig->child;
        insert (cur, temp1->index);
        front_size = 1;
        temp2 = cur->child;
        temp1 = del (temp1);
        temp1 = temp1->child;
        do
        {
            temp2 = cur->child;
            do
            {
                end = 0;
                flag = Dominates(new_pop->m_individuals[temp1->index], new_pop->m_individuals[temp2->index],fc1_constant);
                if (flag == 0)
                {
                    insert (orig, temp2->index);
                    temp2 = del (temp2);
                    front_size--;
                    temp2 = temp2->child;
                }
                if (flag == 2)
                {
                    temp2 = temp2->child;
                }
                if (flag == 1)
                {
                    end = 1;
                }
            }
            while (end!=1 && temp2!=NULL);
            if (flag == 0 || flag == 2)
            {
                insert (cur, temp1->index);
                front_size++;
                temp1 = del (temp1);
            }
            temp1 = temp1->child;
        }
        while (temp1 != NULL);
        temp2 = cur->child;
        do
        {
            new_pop->m_individuals[temp2->index]->m_rank = rank;
            temp2 = temp2->child;
        }
        while (temp2 != NULL);
        assign_crowding_distance_list (new_pop, cur->child, front_size);
        temp2 = cur->child;
        do
        {
            temp2 = del (temp2);
            temp2 = temp2->child;
        }
        while (cur->child !=NULL);
        rank+=1;
    }
    while (orig->child!=NULL);
    free (orig);
    free (cur);
}

/* Insert an element X into the list at location specified by NODE */
void insert (list *node, int x)
{
    list *temp;
    if (node==NULL)
    {
        printf("\n Error!! asked to enter after a NULL pointer, hence exiting \n");
        exit(1);
    }
    temp = (list *)malloc(sizeof(list));
    temp->index = x;
    temp->child = node->child;
    temp->parent = node;
    if (node->child != NULL)
    {
        node->child->parent = temp;
    }
    node->child = temp;
}

/* Delete the node NODE from the list */
list* del (list *node)
{
    list *temp;
    if (node==NULL)
    {
        printf("\n Error!! asked to delete a NULL pointer, hence exiting \n");
        exit(1);
    }
    temp = node->parent;
    temp->child = node->child;
    if (temp->child!=NULL)
    {
        temp->child->parent = temp;
    }
    free (node);
    return (temp);
}

