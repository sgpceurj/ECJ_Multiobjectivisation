//
//  main.cpp
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//
#include <sys/time.h>
#include <iostream>
#include <iomanip>
#include "NSGA2.h"
#include "QAP.h"
#include "Individual.h"


//It is the instance of the problem to optimize.
QAP * PROBLEM;

// The individual size.
int PROBLEM_SIZE=0;

// Number of evaluations performed.
long int EVALUATIONS = 0;

// Convergence evaluation of the best fitness.
long int CONVERGENCE_EVALUATIONS = 0;

// Maximum number of evaluations allowed performed.
long int MAX_EVALUATIONS = 0;

// Name of the file where the result will be stored.
char RESULTS_FILENAME[50];

// Name of the file where the instances is stored.
char INSTANCE_FILENAME[50];

// The seed asigned to the process
int SEED;

//Determines if a solution needs to be inverted before evaluating.
int INVERSE;


/*
 * Get next command line option and parameter
 */
int GetOption (int argc, char** argv, char* pszValidOpts, char** ppszParam)
{
	
    static int iArg = 1;
    char chOpt;
    char* psz = NULL;
    char* pszParam = NULL;
	
    if (iArg < argc)
    {
        psz = &(argv[iArg][0]);
		
        if (*psz == '-' || *psz == '/')
        {
            // we have an option specifier
            chOpt = argv[iArg][1];
			
            if (isalnum(chOpt) || ispunct(chOpt))
            {
                // we have an option character
                psz = strchr(pszValidOpts, chOpt);
				
                if (psz != NULL)
                {
                    // option is valid, we want to return chOpt
                    if (psz[1] == ':')
                    {
                        // option can have a parameter
                        psz = &(argv[iArg][2]);
                        if (*psz == '\0')
                        {
                            // must look at next argv for param
                            if (iArg+1 < argc)
                            {
                                psz = &(argv[iArg+1][0]);
                                if (*psz == '-' || *psz == '/')
                                {
                                    // next argv is a new option, so param
                                    // not given for current option
                                }
                                else
                                {
                                    // next argv is the param
                                    iArg++;
                                    pszParam = psz;
                                }
                            }
                            else
                            {
                                // reached end of args looking for param
                            }
							
                        }
                        else
                        {
                            // param is attached to option
                            pszParam = psz;
                        }
                    }
                    else
                    {
                        // option is alone, has no parameter
                    }
                }
                else
                {
                    // option specified is not in list of valid options
                    chOpt = -1;
                    pszParam = &(argv[iArg][0]);
                }
            }
            else
            {
                // though option specifier was given, option character
                // is not alpha or was was not specified
                chOpt = -1;
                pszParam = &(argv[iArg][0]);
            }
        }
        else
        {
            // standalone arg given with no option specifier
            chOpt = 1;
            pszParam = &(argv[iArg][0]);
        }
    }
    else
    {
        // end of argument list
        chOpt = 0;
    }
	
    iArg++;
	
    *ppszParam = pszParam;
    return (chOpt);
}

/*
 * Help command output.
 */
void usage(char *progname)
{
    cout << "NSGA -i <instance_name> -o <results_name> -s <seed> " <<endl;
    cout <<"   -i File name of the instance.\n"<<endl;
    cout <<"   -o Name of the file to store the results.\n"<<endl;
    cout <<"   -s Seed to be used for pseudo-random numbers generator.\n"<<endl;
}

/*
 * Obtaint the execution parameters from the command line.
 */
bool GetParameters(int argc,char * argv[])
{
	char c;
    if(argc==1)
    {
    	usage(argv[0]);
        return false;
    }
	char** optarg;
	optarg = new char*[argc];
    while ((c = GetOption (argc, argv, ":h:s:o:i:v:",optarg)) != '\0')
    {
    	switch (c)
    	{
                
            case 'h' :
                usage(argv[0]);
                return false;
                break;
                
            case 's' :
                SEED = atoi(*optarg);
                break;
                
            case 'o' :
                strcpy(RESULTS_FILENAME, *optarg);
                break;
                
			case 'i':
                strcpy(INSTANCE_FILENAME, *optarg);
                break;
                
            default:
                cout<<"Wrong parameter specification... "<<endl;
                exit(1);
		
        }
    }

    delete [] optarg;
    
	return true;
}

/*
 * Writes the results of the execution.
 */
void WriteResults(long int best_fitness, int * best, long double time_interval){

    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file<<"Best fitness: "<<setprecision(15)<<best_fitness<<endl;
    output_file<<"Best solution: ";
    for (int i=0;i<PROBLEM_SIZE;i++)
        output_file<<best[i]<<" ";
    output_file<<endl;
    output_file<<"Time consumed: "<<time_interval<<endl;
    output_file.close();
}

void PrintAtDistanceOne(int * genes, int size){
    int i,j;
    int aux;
    double fitness,fc1,fc2,fc3;
    for (i=0; i<PROBLEM_SIZE;i++){
        for (j=0;j<i;j++){
            //swap
            aux=genes[i];
            genes[i]=genes[j];
            genes[j]=aux;
            
            //calculate f and the three components.
            fitness=PROBLEM->Evaluate(genes);
            fc2=PROBLEM->fc2_optimizedV2(genes);
            fc1=PROBLEM->fc1_avg;
            fc3=fitness-fc1-fc2;
            
            printf("%.2f,%.2f,%.2f,%.2f,%d\n",fitness,fc1,fc2,fc3,2);
            
            //unswap
            aux=genes[i];
            genes[i]=genes[j];
            genes[j]=aux;
        }
        for (j=i+1;j<PROBLEM_SIZE;j++){
            //swap
            aux=genes[i];
            genes[i]=genes[j];
            genes[j]=aux;
            
            //calculate f and the three components.
            fitness=PROBLEM->Evaluate(genes);
            fc2=PROBLEM->fc2_optimizedV2(genes);
            fc1=PROBLEM->fc1_avg;
            fc3=fitness-fc1-fc2;
            
            printf("%.2f,%.2f,%.2f,%.2f,%d\n",fitness,fc1,fc2,fc3,2);
            
            //unswap
            aux=genes[i];
            genes[i]=genes[j];
            genes[j]=aux;
        }
    }
}

void Pareto_Analysis(){
    string path=(string)INSTANCE_FILENAME;
    
    std::string base_filename = path.substr(path.find_last_of("/") + 1);
    cout<<base_filename;
    
    ///////////////////////////////////////////////////////////////////////
    // 1. Create a random population of solutions and evaluate f and fc. //
    ///////////////////////////////////////////////////////////////////////
    int total_samples_num=10000;
    int best_samples_num=total_samples_num*0.1;
    int i;
    double f,fc1,fc2,fc3;
    CPopulation * sample = new CPopulation(total_samples_num, PROBLEM_SIZE);
    int * genes= new int[PROBLEM_SIZE];
    double * fc= new double[3];
    CIndividual * aux= new CIndividual(PROBLEM_SIZE);
    for(i=0;i<total_samples_num;i++)
    {
        //Create random individual
        GenerateRandomPermutation(genes,PROBLEM_SIZE);
        f=PROBLEM->Evaluate(genes);
        sample->SetToPopulation(genes, i, f,fc);
    }
    sample->SortPopulation(aux);
    for(i=0;i<best_samples_num;i++)
    {
        //Create random individual
        f=sample->m_individuals[i]->m_value;
        if (PROBLEM->m_fc1_constant==1){
            fc2=PROBLEM->fc2_optimizedV2(sample->m_individuals[i]->m_genes);
            fc1=PROBLEM->fc1_avg;
            fc3=f-fc1-fc2;
            fc[0]=fc1;
            fc[1]=fc2;
            fc[2]=fc3;
        }
        else{
            PROBLEM->f_components(sample->m_individuals[i]->m_genes,fc);
            fc[2]=f-fc[0]-fc[1];
        }
        sample->SetToPopulation(sample->m_individuals[i]->m_genes, i, f,fc);
    }
    delete [] genes;
    delete [] fc;
    delete aux;
    ///////////////////////////
    // 2. Calculate Paretos. //
    ///////////////////////////
    sample->CalculateParetos( PROBLEM->m_fc1_constant,best_samples_num);
    exit(1);
}

void Correspondence_Analysis (){
    string path=(string)INSTANCE_FILENAME;
    
    std::string base_filename = path.substr(path.find_last_of("/") + 1);
    cout<<base_filename;
    /////////////////////////////////////////
    // 0. Auxiliary variable declarations. //
    /////////////////////////////////////////
    double f;
    double fc1=MAX_LONG_INTEGER,fc2=MAX_LONG_INTEGER,fc3=MAX_LONG_INTEGER;
    int i, j;
    int * genes= new int[PROBLEM_SIZE];
    CIndividual * ind1, * ind2;
    CIndividual * aux= new CIndividual(PROBLEM_SIZE);
    ///////////////////////////////////////////////////////////////////////
    // 1. Create a random population of solutions and evaluate f and fc. //
    ///////////////////////////////////////////////////////////////////////
    
    int correspond=0;
    int contrary=0;
    int neutral=0;
    int total_samples_num=10000;
    int best_samples_num=total_samples_num*0.1;
    int comparisons=(best_samples_num*(best_samples_num-1))/2;
    CPopulation * sample = new CPopulation(total_samples_num, PROBLEM_SIZE);
    double * fc= new double[3];
    int reps=5;
    for (int z=0;z<reps;z++){
        // cout<<"z: "<<z<<endl;
        //printf("Creating random population...\n");
        
        for(i=0;i<total_samples_num;i++)
        {
            //Create random individual
            GenerateRandomPermutation(genes,PROBLEM_SIZE);
            f=PROBLEM->Evaluate(genes);
            
            sample->SetToPopulation(genes, i, f,fc);
        }
        
        sample->SortPopulation(aux);
        for(i=0;i<best_samples_num;i++)
        {
            //Create random individual
            f=sample->m_individuals[i]->m_value;
            if (PROBLEM->m_fc1_constant==1){
                fc2=PROBLEM->fc2_optimizedV2(sample->m_individuals[i]->m_genes);
                fc1=PROBLEM->fc1_avg;
                fc3=f-fc1-fc2;
                fc[0]=fc1;
                fc[1]=fc2;
                fc[2]=fc3;
            }
            else{
                PROBLEM->f_components(sample->m_individuals[i]->m_genes,fc);
                fc[2]=f-fc[0]-fc[1];
            }
            
            sample->SetToPopulation(sample->m_individuals[i]->m_genes, i, f,fc);
        }
        
        ///////////////////////////////////
        // 2. Calculate correspondences. //
        ///////////////////////////////////
        //printf("Calculating correspondences...\n");
        
        int dominance=-1;
        for(i=0;i<best_samples_num;i++)
        {
            ind1=sample->m_individuals[i];
            //ind1->Print();
            for(j=i+1;j<best_samples_num;j++)
            {
                ind2=sample->m_individuals[j];
                // ind2->Print();
                dominance=Dominates(ind1, ind2, PROBLEM->m_fc1_constant);
                //cout<<"dominance: "<<dominance<<endl;
                //cout<<"-------------------------------------"<<endl;
                if (ind1->m_value < ind2->m_value) // f(ind1) is better than f(ind2).
                {
                    if (dominance==0) //ind1 dominates ind2
                        correspond++;
                    else if (dominance==1)//ind2 dominates ind1
                        contrary++;
                    else //ind1 and ind2 are in the same front
                        neutral++;
                }
                else if (ind1->m_value > ind2->m_value) //f(ind1) is worse than f(ind2).
                {
                    if (dominance==0) //ind1 dominates ind2
                        contrary++;
                    else if (dominance==1)//ind2 dominates ind1
                        correspond++;
                    else //ind1 and ind2 are in the same front
                        neutral++;
                }
                else //f(ind1) is equal to f(ind2).
                {
                    if (dominance==0) //ind1 dominates ind2
                        neutral++;
                    else if (dominance==1)//ind2 dominates ind1
                        neutral++;
                    else //ind1 and ind2 are in the same front
                        correspond++;
                    
                }
            }
        }
        //printf("--------------------------------------------------\n");
        //printf("Comparisons: %d\n",comparisons);
        //printf("Correspondence comparisons: %d (ratio %g)\n",correspond,(double)correspond/(double)comparisons);
        //printf("Neutral comparisons: %d (ratio %g)\n",neutral,(double)neutral/(double)comparisons);
        //printf("--------------------------------------------------\n");
        
    }
    delete [] genes;
    delete [] fc;
    delete sample;
    
    printf(";%g;%g\n",(double)correspond/(double)(comparisons*reps),(double)neutral/(double)(comparisons*reps));
    exit(1);
}

/*
 * Main function.
 */
int main(int argc, char * argv[])
{
    //Initialize time variables.
    struct timeval tim;
    gettimeofday(&tim, NULL);
    double t1=tim.tv_sec+(tim.tv_usec/1000000.0);
    
    //Get parameters
#ifdef VERBOSE
     cout<<"Parsing parameters..."<<endl;
#endif
	if(!GetParameters(argc,argv)) return -1;

    //Set seed
    srand(SEED*1000);
    //Read the problem instance to optimize.
#ifdef VERBOSE
    cout<<"Reading instance..."<<INSTANCE_FILENAME<<endl;
#endif
    PROBLEM= new QAP();
    PROBLEM_SIZE= PROBLEM->Read((string)INSTANCE_FILENAME);
   
#ifdef CORRESPONDENCE_ANALYSIS
    Correspondence_Analysis();
#endif
    
#ifdef PARETO_ANALYSIS
    Pareto_Analysis();
#endif
    
    MAX_EVALUATIONS=PROBLEM_SIZE*PROBLEM_SIZE*1000;

#ifdef VERBOSE
    cout<<"Building NSGA2...."<<endl;
#endif
    NSGA2 * nsga2= new NSGA2(PROBLEM,PROBLEM_SIZE, MAX_EVALUATIONS);
    nsga2->Run();
    
    //Get best solution fitness and the number of evaluations performed.
    CIndividual * best = nsga2->GetBestSolution();
    
#ifdef SPACE_ANALYSIS
    printf("f,fc1,fc2,fc3,dist\n");
    int i,j,l,m;
    double fitness,fc1,fc2,fc3;
    for (int k=0;k<10000;k++){
        i=rand()%PROBLEM_SIZE;
        j=rand()%PROBLEM_SIZE;
        l=rand()%PROBLEM_SIZE;
        m=rand()%PROBLEM_SIZE;
        
        Swap(best->m_genes, i, j);
        Swap(best->m_genes, l, m);
        
        //calculate f and the three components.
        fitness=PROBLEM->Evaluate(best->m_genes);
        fc2=PROBLEM->fc2_optimizedV2(best->m_genes);
        fc1=PROBLEM->fc1_avg;
        fc3=fitness-fc1-fc2;
        
        printf("%.2f,%.2f,%.2f,%.2f,%d\n",fitness,fc1,fc2,fc3,2);
        
        Swap(best->m_genes, l, m);
        Swap(best->m_genes, i, j);
    }
    
#endif

    
    gettimeofday(&tim, NULL);
    double t2=tim.tv_sec+(tim.tv_usec/1000000.0);

    //Create the file to store the results.
    ofstream output_file;
    output_file.open(RESULTS_FILENAME);
    output_file.close();
#ifdef VERBOSE
    cout<<"B: "<<best->m_value<<endl;
#endif

    //Print results
    WriteResults(best->m_value,best->m_genes,t2-t1);
    
    delete best;
    delete PROBLEM;
    delete nsga2;
    
    return 0;
}

