//
//  Population.cc
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#include "Population.h"

using std::istream;
using std::ostream;
using std::cerr;
using std::cout;
using std::endl;

/*
 * Constructor function.
 */
CPopulation::CPopulation(int pop_size, int individual_size)
{
    m_pop_size=pop_size;
    m_individuals.resize(m_pop_size);
    m_problem_size=individual_size;
    
    //Initialize population with empty solutions
    for (int i=0;i<m_pop_size;i++)
    {
        m_individuals[i]= new CIndividual(individual_size);
    }
    
    m_n=new int[m_pop_size];
    m_marks= new int[m_pop_size];
    
}

/*
 * Destructor function.
 */
CPopulation::~CPopulation()
{
    for (int i=0;i<m_pop_size;i++)
    {
        delete m_individuals[i];
    }
    m_individuals.clear();
    delete [] m_n;
    delete [] m_marks;
}
/*
 * Function to set an individual in a specific position of the population
 */
void CPopulation::SetToPopulation(int * genes, int index, int fitness)
{
    memcpy( m_individuals[index]->m_genes, genes, sizeof(int)*m_problem_size);
    m_individuals[index]->m_value=fitness;
}


/*
 * Function to set an individual in a specific position of the population
 */
void CPopulation::SetToPopulation(int * genes, int index, int fitness, float fc2, float fc3)
{
    memcpy( m_individuals[index]->m_genes, genes, sizeof(int)*m_problem_size);
    m_individuals[index]->m_value=fitness;
    m_individuals[index]->m_fc2=fc2;
    m_individuals[index]->m_fc3=fc3;
}

/*
 *
 */
bool CPopulation::Exists(int index, int fitness){

    bool exists=true;
    int bound= m_pop_size+index;
    int i;
    for(i=0;i<bound && fitness!=m_individuals[i]->m_value; i++);
    if (i==bound)
        exists=false;
    return exists;
}

/*
 * Prints the current population.
 */
void CPopulation::Print()
{
	for(int i=0;i<m_pop_size; i++)
		cout<<m_individuals[i]->m_value<<",  "<<m_individuals[i]->m_fc2<<","<<m_individuals[i]->m_fc3<<"  [ "<<m_individuals[i]<<" ]"<<endl;
}

/*
 * Prints the current population.
 */
void CPopulation::Print(int samples)
{
	for(int i=0;i<samples; i++)
		cout<<m_individuals[i]->m_value<<"  [ "<<m_individuals[i]<<" ]"<<endl;
}


/*
 * Calculates the average fitness of the first 'size' solutions in the population
 */
float CPopulation::AverageFitnessPopulation(int size)
{
	float result=0;
	for(int i=0;i<size;i++)
    {
        result+=m_individuals[i]->m_value;
    }
    return result/size;
    
}

/*
 * Returns the best individual of the population.
 */
CIndividual * CPopulation::BestIndividual(){
    int best_index=0;

    for (int i=1;i<m_pop_size;i++){
        if (m_individuals[i]->m_value<m_individuals[best_index]->m_value)
            best_index=i;
    }
    return m_individuals[best_index];
}

/*
 * Sorts the individuals in the population in ascending order of the fitness value.
 * returns true if the best solution was outperformed.
 */
bool CPopulation::SortPopulation(CIndividual * best)
{
    sort(m_individuals.begin(), m_individuals.begin()+m_pop_size, Better);
    if (m_individuals[0]->m_value<best->m_value){
            Copy_Ind(m_individuals[0], best);
            return true;
    }
    return false;
}

/*
 *  Performs the nondominated sorting of the NSGA-II proposed by debt et al.
 */
bool CPopulation::Fast_NonDominatedSorting(CIndividual * best){
    
    int p,q;
    bool improved=false;
    m_S.resize(m_pop_size);
    m_F.resize(1);
    m_clone.resize(0);

    
    //first pareto.
    for (p=0;p<m_pop_size;p++){
        m_S[p].resize(0);
        m_n[p]=0;
        for (q=0;q<m_pop_size;q++){
            if (m_individuals[p]->m_fc2<m_individuals[q]->m_fc2 &&
                m_individuals[p]->m_fc3<m_individuals[q]->m_fc3){
                m_S[p].push_back(q);
            }
            else if (m_individuals[p]->m_fc2>m_individuals[q]->m_fc2 &&
                     m_individuals[p]->m_fc3>m_individuals[q]->m_fc3){
                m_n[p]++;
            }
        }
        if (m_n[p]==0){
            m_marks[p]=1;
            m_F[0].push_back(p);
        }
    }
    int i=0,z,w;

    while(!m_F[i].empty()){
        m_F.resize(m_F.size()+1);
        for (z=0;z<m_F[i].size();z++){
            p=m_F[i][z];
            for (w=0;w<m_S[p].size();w++){
                q=m_S[p][w];
                m_n[q]--;
                if (m_n[q]==0){
                    m_marks[q]=i+2;
                    m_F[i+1].push_back(q);
                }
            }
        }
        i++;
    }
    
    m_F.resize(m_F.size()-1);
    int a=0, b=0, j;
    for (i=0;i<m_F.size();i++){
        for (j=0;j<m_F[i].size();j++){
            m_clone.push_back(m_individuals[m_F[i][j]]);
        }
        b=b+(int)m_F[i].size();
        sort(m_clone.begin()+a,m_clone.begin()+b,Better);
        if (m_clone[a]->m_value<best->m_value){
            Copy_Ind(m_clone[a],best);
            improved=true;
        }
        a=b;
    }
    m_individuals.clear();
    m_individuals=m_clone;
    m_F.clear();
    m_S.clear();
    m_clone.clear();

    return improved;
}



