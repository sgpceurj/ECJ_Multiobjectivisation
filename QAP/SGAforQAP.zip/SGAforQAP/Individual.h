//
//  Individual.h
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#ifndef _INDIVIDUAL_
#define _INDIVIDUAL_

#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <limits.h>
#include <iostream>
#include "Variables.h"
using namespace std;
using std::istream;
using std::ostream;

class CIndividual
{
public:

	// The constructor. The constructed individual has
	// all zeroes as its genes.
	CIndividual(int length);

	// The destructor. It frees the memory allocated at
	// the construction of the individual.
	virtual ~CIndividual();

    /*
     * Prints in the standard output genes.
     */
	void PrintGenes();

    /*
     * Output operator.
     */
	friend ostream & operator<<(ostream & os,CIndividual * & individual);
    
    /*
     * Input operator.
     */
	friend istream & operator>>(istream & is,CIndividual * & individual);

    
    /*
     * The landscape components of the solution.
     */
    float m_fc1, m_fc2, m_fc3;
    
	/*
     * The variable storing the individual's fitness value.
     */
	int m_value;

    
    /*
     * The genes of the individual.
     */
	int * m_genes;

    /*
     * The size of the individual
     */
	int m_size;

private:
	
    

    
};

#endif
