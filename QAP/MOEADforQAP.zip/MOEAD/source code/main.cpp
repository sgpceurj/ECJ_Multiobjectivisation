//
//  main.cpp
//  MOEADforQAP
//
//  Created by Josu Ceberio Uribe on 10/06/15.
//  Copyright (c) 2015 University of the Basque Country. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
