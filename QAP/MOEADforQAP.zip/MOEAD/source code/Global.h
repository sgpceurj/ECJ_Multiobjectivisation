#ifndef __GLOBAL_H_
#define __GLOBAL_H_

// #define VERBOSE 1

#include <cstdlib>
#include <cmath>
#include <fstream>
#include <iostream>
#include <vector>
#include <ctime>
#include <string>
#include <time.h>

using namespace std;

extern int  seed;
extern long rnd_uni_init;

extern int  NumberOfItems;
extern int  NumberOfELDComponents;
extern int  NumberOfObjectives;
extern vector<double> ReferencePoint;
extern vector<double> ReferencePoint_Nadir;


extern char strFitnessType[1024];

extern int run_id;

#endif
