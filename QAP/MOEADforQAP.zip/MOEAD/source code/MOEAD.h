// MOEAD.h: interface for the CMOEAD class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MOEAD_H__968492DD_9800_4780_ABA8_6F78D3D1491E__INCLUDED_)
#define AFX_MOEAD_H__968492DD_9800_4780_ABA8_6F78D3D1491E__INCLUDED_

#include "RandomNumber.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include  "QAP.h"
#include  "Global.h"
#include  "Individual.h"
#include  "WeightVector.h"
#include  "SubProblem.h"

class CMOEAD  
{
public:
	CMOEAD(int problem_size, QAP * problem, int se);
	virtual ~CMOEAD();


public:
	vector<CSubProblem> CurrentPopulation;  //  population of subproblems
	vector<CIndividual> SecondPopulation;   //  external population containing all nondominated solutions found 

public:
    int m_problem_size;                     //  problem size
	int PopulationSize;                     //  population size
	long int MaxNumOfFuncEvals;             //  the maximal number of function evaluations
	int NeighborhoodSize;                   //  neighborhood size
	int NumberOfFuncEvals;                  //  counter for function evaluations
	CRandomNumber Rnd;                      //  uniform random number generator
    QAP * m_problem;                        //  QAP instance
    CIndividual * m_best;                   //  The best solution found so far

public:
	void SaveSecondPopulation();
	void Show();
	void MinFastSort(vector<double> &dist, vector<int> &indx, int n, int m);

	void InitializePopulation();
	void InitializeWeightVector();
	void InitializeNeighborhood();
	void InitializeReferencePoint();

	void UpdateReferencePoint(CIndividual &ind);
	void UpdateSecondPopulation(CIndividual &ind);
	void UpdateNeighboringSolution(CIndividual &ind, int iPop);

	void Run(long int fevals);
    
    CIndividual * GetBestSolution();
    bool Exists(double fitness);
    
    void PrintArray(int* array, int length, string text);   // Prints in standard output 'length' integer elements of a given array.
    void Crossover_OPX(CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2);
};

#endif // !defined(AFX_MOEAD_H__968492DD_9800_4780_ABA8_6F78D3D1491E__INCLUDED_)
