// Individual.h: interface for the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDIVIDUAL_H__2BA89BEB_BCB1_491E_8980_761AF58D14BC__INCLUDED_)
#define AFX_INDIVIDUAL_H__2BA89BEB_BCB1_491E_8980_761AF58D14BC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Global.h"
#include "QAP.h"
#include "RandomNumber.h"

using namespace std;

class CIndividual  
{
public:
	CIndividual();
	CIndividual(int length, QAP * problem);
	virtual ~CIndividual();

public:
    
    double * m_fcomponents;    //The component's coefficients of the elementary landscape decomposition.
    
    double m_fitness_value;  //The fitness value of the solution.
    
    int * m_genes;      //The genes of the solution.
    
    int m_size;     //The size of the solution (number of genes).
    
    QAP * m_problem;

    bool initialized=false;     //Indicates whether the CIndividual structure has been initialized.

public:
	   CRandomNumber    Rnd;
	   bool             dominated;

public:
	   void   SinglePointXover(CIndividual &parent1, CIndividual &parent2);
       void   Crossover_OPX (CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2 );
	   double ComputingFitnessValue(vector<double> &lambda, char *strFuncType);
	   void   Randomize(int length, QAP * problem);
       void   Initialize(int length, QAP * problem);
       void   Show();                          // Prints the individual in the standard output.
       void   Clone(CIndividual ind);          // Clones the individual.
       void   ComputingProfitValue();          // function computing
       void   ComputingCapacityValue();        // capacity computing
       void   Compute_fComponents();

       bool operator==(const CIndividual& ind);
       bool operator>(const  CIndividual& ind);
	   bool operator<(const  CIndividual& ind);
};

#endif // !defined(AFX_INDIVIDUAL_H__2BA89BEB_BCB1_491E_8980_761AF58D14BC__INCLUDED_)
