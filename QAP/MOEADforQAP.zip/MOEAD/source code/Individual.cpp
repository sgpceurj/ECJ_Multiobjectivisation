// Individual.cpp: implementation of the CIndividualividual class.
//
//////////////////////////////////////////////////////////////////////

#include "Individual.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CIndividual::CIndividual()
{
    initialized=false;
}

CIndividual::CIndividual(int length, QAP * problem)
{
    Initialize(length, problem);
}

CIndividual::~CIndividual()
{

}

/*
 * Clones the individual.
 */
void CIndividual::Clone(CIndividual ind)
{
    if (initialized==false){
        Initialize(ind.m_size,ind.m_problem);
    }
    m_size=ind.m_size;
    m_problem=ind.m_problem;
    memcpy(m_genes,ind.m_genes,sizeof(int)*m_size);
    memcpy(m_fcomponents, ind.m_fcomponents, sizeof(double)*NumberOfELDComponents);
    m_fitness_value=ind.m_fitness_value;
}

void CIndividual::Initialize(int length, QAP * problem){
    m_size = length;
    m_genes = new int[m_size];
    m_problem=problem;
    m_fitness_value = INFINITY;
    m_fcomponents= new double[3];
    m_fcomponents[0] = m_problem->fc1_avg;
    m_fcomponents[1] = INFINITY;
    m_fcomponents[2] = INFINITY;

    initialized=true;
}

// randomly initialize solution
void CIndividual::Randomize(int length, QAP * problem)
{
    Initialize(length,problem);
    
    //generate random permutation of genes
    for (int i = 0; i < m_size; ++i)
    {
        int j = rand() % (i + 1);
        m_genes[i] = m_genes[j];
        m_genes[j] = i;
    }
    
    m_fitness_value=m_problem->Evaluate(m_genes);
    
    m_fcomponents[1]=m_problem->fc2_optimizedV2(m_genes);
    m_fcomponents[2]=m_fitness_value-m_fcomponents[0]-m_fcomponents[1];//m_problem->fc3(m_genes);
}

void CIndividual::Compute_fComponents(){
    
    m_fitness_value=m_problem->Evaluate(m_genes);

    m_fcomponents[1]=m_problem->fc2_optimizedV2(m_genes);
    m_fcomponents[2]=m_fitness_value-m_fcomponents[0]-m_fcomponents[1];//m_problem->fc3(m_genes);
}


double CIndividual::ComputingFitnessValue(vector<double> &lambda, char *strFuncType)
{
	double fitness= 0.0;
	if(strcmp(strFuncType,"_WEIGHTEDSUM")==0)
	{
		fitness = 0;
        //lambda[0]=0.85;
        //lambda[1]=0.15;
		for (int i = 1; i <= NumberOfObjectives; i++)
		{
          //  fitness += lambda[i-1]*(ReferencePoint[i-1]-this->m_fcomponents[i]);
            fitness += lambda[i-1]*(this->m_fcomponents[i] - ReferencePoint[i-1])/(ReferencePoint_Nadir[i-1]-ReferencePoint[i-1]);
        }
	}


	if(strcmp(strFuncType,"_TCHEBYCHEFF")==0)
	{
		fitness = -1e30;
        double dif;
		for (int i = 1; i <= NumberOfObjectives; i++)
		{
            //dif = 1.1*ReferencePoint[i] - this->m_fcomponents[i];
            dif = this->m_fcomponents[i]-1.1*ReferencePoint[i-1];
			double s = lambda[i-1]*(dif>0?dif:-dif);
			if (s >	fitness) 	fitness = s;
		}
	}

	return fitness;
}


bool CIndividual::operator>(const CIndividual& indiv)
{
    for(int i=1;i<=NumberOfObjectives;i++)
        if(indiv.m_fcomponents[i]>m_fcomponents[i])
            return false;
    return true;
}

bool CIndividual::operator<(const CIndividual& indiv)
{
    for(int i=1;i<=NumberOfObjectives;i++)
        if(indiv.m_fcomponents[i]<m_fcomponents[i])
            return false;
    return true;
}

bool CIndividual::operator==(const CIndividual& indiv)
{
    for(int i=1;i<=NumberOfObjectives;i++)
        if(indiv.m_fcomponents[i]!=m_fcomponents[i])
            return false;
    return true;
}

/*
 * Prints the individual in the standard output.
 */
void CIndividual::Show()
{
    cout<<"f: "<<m_fitness_value<<"  fc1: "<<m_fcomponents[0]<<"  fc2: "<<m_fcomponents[1]<<"  fc3: "<<m_fcomponents[2]<<"    ";
    for (int i=0;i<m_size;i++){
        cout<<m_genes[i]<<" ";
    }
    cout<<endl;
}


