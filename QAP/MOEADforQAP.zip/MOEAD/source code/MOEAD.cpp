// MOEAD.cpp: implementation of the CMOEAD class.
//
//////////////////////////////////////////////////////////////////////

#include "MOEAD.h"
#include "Global.h"
#include <limits.h>
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMOEAD::CMOEAD(int problem_size, QAP * problem, int se)
{
    m_problem_size  =   problem_size;
    m_problem   =   problem;
    NeighborhoodSize    = problem_size/4;
	NumberOfFuncEvals   = 0;	
    NumberOfELDComponents= 3;
    NumberOfObjectives= 2;

    ReferencePoint = vector<double>(NumberOfObjectives, INFINITY);
    ReferencePoint_Nadir=vector<double>(NumberOfObjectives, INFINITY);

	seed         =  se;
    seed         =  (seed + 3111)%77559; //(unsigned)time(NULL);
    rnd_uni_init = -(long)seed;
    
    m_best= new CIndividual(m_problem_size, m_problem);

}

CMOEAD::~CMOEAD()
{

}

// read predefined weight vectors from txt files
void CMOEAD::InitializeWeightVector()
{
	ifstream indata;
    indata.open("weights.dat"); // opens the file
    if(!indata) { // file couldn't be opened
      cerr << "Error: file could not be opened" << endl;
      exit(1);
	}
    
    indata>>PopulationSize;
	CSubProblem subp;
    int i, iObj;
    
	for(i=1; i<=PopulationSize; i++)
	{
		for(iObj=0; iObj<NumberOfObjectives; iObj++)
		{		    
			indata>>subp.WeightVector.lambda[iObj];
		}
        CurrentPopulation.push_back(subp);
    }
	indata.close();

}

// initialize population with N solutions
void CMOEAD::InitializePopulation()
{
    
    for(int iPop=0; iPop<CurrentPopulation.size(); iPop++)
	{
	    CurrentPopulation[iPop].CurrentSolution.Randomize(m_problem_size,m_problem);

		UpdateReferencePoint(CurrentPopulation[iPop].CurrentSolution);
		NumberOfFuncEvals++;
	}
    
/*#ifdef VERBOSE
    for(int iPop=0; iPop<CurrentPopulation.size(); iPop++)
    {
        CurrentPopulation[iPop].CurrentSolution.Show();
    }
#endif*/
}


// compare the offspring solution with its neighhoring solutions
void CMOEAD::UpdateNeighboringSolution(CIndividual &offspring, int iPop)
{
    double f1, f2, id;

    for(int n=0; n<NeighborhoodSize; n++)
	{
		id = CurrentPopulation[iPop].IndexOfNeighbor[n];    // the index of neighboring subproblem
		f1 = offspring.ComputingFitnessValue(CurrentPopulation[id].WeightVector.lambda, strFitnessType);  // fitness of the offspring

		f2 = CurrentPopulation[id].CurrentSolution.ComputingFitnessValue(CurrentPopulation[id].WeightVector.lambda, strFitnessType);  // fitness of neighbors
        
		// if offspring is better, then update the neighbor
        
		if(offspring.m_fitness_value<CurrentPopulation[id].CurrentSolution.m_fitness_value || f1<f2)
        {
            CurrentPopulation[id].CurrentSolution.Clone(offspring);
            break;
		}
	}
}

// update the reference point with the best value for each objective
void CMOEAD::UpdateReferencePoint(CIndividual &ind)
{
        if (ind.m_fcomponents[1]<ReferencePoint[0])
        {
			ReferencePoint[0] = ind.m_fcomponents[1];
		}
        if (ind.m_fcomponents[2]<ReferencePoint[1])
        {
            ReferencePoint[1] = ind.m_fcomponents[2];
        }
/*#ifdef VERBOSE
    cout<<"Ref. p.: ";
    for (int i=0;i<NumberOfObjectives;i++){
        cout<<ReferencePoint[i]<<" ";
    }
    cout<<" "<<endl;
#endif*/
}


// determine the neighboring relationship between subproblems according to 
// the distances between weight vectors
void CMOEAD::InitializeNeighborhood()
{
    double tp;
    int iPop, iPop2, i;
    for(iPop=0; iPop<PopulationSize; iPop++)
    {
	   vector<int>    indx;
	   vector<double> dist;

       for(iPop2=0; iPop2<PopulationSize; iPop2++)
	   {
		   indx.push_back(iPop2);
           tp = CurrentPopulation[iPop].WeightVector.DistanceTo(CurrentPopulation[iPop2].WeightVector);
		   dist.push_back(tp);
	   }
	   
	   this->MinFastSort(dist, indx, PopulationSize, NeighborhoodSize+1);


	   for(i=0; i<NeighborhoodSize+1; i++)
	   {
	       CurrentPopulation[iPop].IndexOfNeighbor.push_back(indx[i]);
	   }

	   indx.clear();
	   dist.clear();
   }
}

void CMOEAD::InitializeReferencePoint()
{
	for(int iObj=0; iObj<NumberOfObjectives; iObj++)
	{
		CIndividual * ind= new CIndividual(m_problem_size, m_problem);
		ind->Randomize(m_problem_size, m_problem);
		this->UpdateReferencePoint(*ind);
	}
    
#ifdef VERBOSE
    cout<<"Ref. p.: ";
    for (int i=0;i<NumberOfObjectives;i++){
        cout<<ReferencePoint[i]<<" ";
    }
    cout<<" "<<endl;
#endif
}

void CMOEAD::MinFastSort(vector<double> &dist, vector<int> &indx, int n, int m)
{
    int i,j,id;
    double temp;
	for(i=0; i<m; i++)
	{
		for(j=i+1;j<n; j++)
		{
			if(dist[i]>dist[j])
			{
                temp = dist[i];
				dist[i]     = dist[j]; 
				dist[j]		= temp;
				id      = indx[i];
				indx[i]     = indx[j];
				indx[j]		= id;
			}
		}
	}
}


void CMOEAD::UpdateSecondPopulation(CIndividual &ind)
{
	//*
	int iCount = 0;
    int n;
    for(n=0; n<SecondPopulation.size(); n++)
	{

		if(ind==SecondPopulation[n])
			return;

		if(SecondPopulation[n]<ind)
			return;

		if(SecondPopulation[n]>ind)
		{
			SecondPopulation[n].dominated = true;
			iCount++;
		}
		else
		{
			SecondPopulation[n].dominated = false;
		}
	}

	for(n=0; n<SecondPopulation.size(); n++)
	{
		if(SecondPopulation[n].dominated)
		{
			SecondPopulation.erase(SecondPopulation.begin()+n);
			n--;
		}
	}

	SecondPopulation.push_back(ind);    
}

void CMOEAD::Show()
{
    for(int iPop=0; iPop<SecondPopulation.size(); iPop++)
	{
		printf("\n");
		SecondPopulation[iPop].Show();
	}

	printf("\n");
}

void CMOEAD::SaveSecondPopulation()
{
	std::fstream fout;
	fout.open("population.dat",std::ios::out);
    int n,k;
	for(n=0; n<SecondPopulation.size(); n++)
	{
        fout<<"f: "<<SecondPopulation[n].m_fitness_value<<" ";
		for(k=0; k<NumberOfELDComponents; k++)
		{
			fout<<SecondPopulation[n].m_fcomponents[k]<<" ";
		}
		fout<<"\n";
	}
	fout.close();
}

/*
 * Prints in standard output 'length' integer elements of a given array.
 */
void CMOEAD::PrintArray(int* array, int length, string text)
{
    cout<<text;
    for (int i=0;i<length;i++){
        cout<<array[i]<<" ";
    }
    cout<<" "<<endl;
}

bool Remove(vector<int> * v, int element){
    
    for (int i=0;i<v->size();i++){
        if (element==v->at(i)){
            v->erase(v->begin()+i);
            return true;
        }
    }
    return false;
}

/*
 * Crossover operator. OPX
 */
void CMOEAD::Crossover_OPX (CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2){
    
    int i;
    vector<int> non_used_parent1; int index_non_used1=0;
    vector<int> non_used_parent2; int index_non_used2=0;
    int element1,element2;
    for (i=0;i<m_problem_size;i++) {
        element1=parent1->m_genes[i];
        element2=parent2->m_genes[i];
        if (EQUAL(element1, element2)==0){
            child1->m_genes[i]=-1;
            child2->m_genes[i]=-1;
            non_used_parent1.push_back(element1);
            non_used_parent2.push_back(element2);
        }
        else{
            child1->m_genes[i]=element1;
            child2->m_genes[i]=element2;
        }
    }
    
    int crossover_point= (rand()% (m_problem_size-2));
    memcpy(child1->m_genes, parent1->m_genes, sizeof(int)*(crossover_point+1));
    memcpy(child2->m_genes, parent2->m_genes, sizeof(int)*(crossover_point+1));
    
    for (i=0;i<=crossover_point;i++){
        Remove(&non_used_parent2, parent1->m_genes[i]);
        Remove(&non_used_parent1, parent2->m_genes[i]);
    }
    
    for (i=crossover_point+1;i<m_problem_size;i++){
        if (child1->m_genes[i]==-1){
            child1->m_genes[i]=non_used_parent2.at(index_non_used2);
            index_non_used2++;
        }
        if (child2->m_genes[i]==-1){
            child2->m_genes[i]=non_used_parent1.at(index_non_used1);
            index_non_used1++;
        }
    }
    non_used_parent1.clear();
    non_used_parent2.clear();
}


void CMOEAD::Run(long int fevals)
{

	MaxNumOfFuncEvals = fevals;

#ifdef VERBOSE
    cout<<"Initializing reference point..."<<endl;
#endif
	this->InitializeReferencePoint();
    
#ifdef VERBOSE
    cout<<"Initializing weight vector..."<<endl;
#endif
    this->InitializeWeightVector();
	
#ifdef VERBOSE
    cout<<"Initializing neighborhood..."<<endl;
#endif
	this->InitializeNeighborhood();

#ifdef VERBOSE
    cout<<"Initializing population..."<<endl;
#endif
	this->InitializePopulation();

	int   gen = 1;

#ifdef VERBOSE
    cout<<"Looping..."<<endl;
#endif
    int id1,id2,p1,p2, iPop;
    
#ifdef VERBOSE
    cout<<"-------Gen "<<gen<<" ---------------"<<endl;
    for(iPop=0; iPop<5; iPop++)
    {
        CurrentPopulation[iPop].CurrentSolution.Show();
    }
    cout<<"------------------------------------"<<endl;
#endif
	while(NumberOfFuncEvals<MaxNumOfFuncEvals)
	{
		gen++;

		for(iPop=0; iPop<PopulationSize; iPop++)
		{
			// select two neighboring solutions randomly
			id1 = int(Rnd.GetNumber()*NeighborhoodSize);
			id2 = int(Rnd.GetNumber()*NeighborhoodSize);
            
			p1 = CurrentPopulation[iPop].IndexOfNeighbor[id1];
			p2 = CurrentPopulation[iPop].IndexOfNeighbor[id2];
            //cout<<"p1: "<<p1<<" p2: "<<p2<<endl;
            //PrintArray(CurrentPopulation[p1].CurrentSolution.m_genes, m_problem_size, "parent1: ");
            //PrintArray(CurrentPopulation[p2].CurrentSolution.m_genes, m_problem_size, "parent2: ");
            
			// produce an offspring solution
            CIndividual offspring1; offspring1.Initialize(m_problem_size,m_problem);
            CIndividual offspring2; offspring2.Initialize(m_problem_size,m_problem);
            CIndividual offspring;
            if (CurrentPopulation[p1].CurrentSolution.m_fitness_value<CurrentPopulation[p2].CurrentSolution.m_fitness_value)
                Crossover_OPX(&CurrentPopulation[p1].CurrentSolution, &CurrentPopulation[p2].CurrentSolution, &offspring1, &offspring2);
            else
                Crossover_OPX(&CurrentPopulation[p2].CurrentSolution, &CurrentPopulation[p1].CurrentSolution, &offspring1, &offspring2);
            
            //PrintArray(offspring1.m_genes, m_problem_size, "child1: ");
            //PrintArray(offspring2.m_genes, m_problem_size, "child2: ");
            
            offspring1.Compute_fComponents();NumberOfFuncEvals++;
            offspring2.Compute_fComponents();NumberOfFuncEvals++;

            if (offspring2.m_fitness_value>offspring1.m_fitness_value)
                offspring=offspring1;
            else
                offspring=offspring2;
            
            if (Exists(offspring.m_fitness_value)==false){
                if (m_best->m_fitness_value>offspring.m_fitness_value){
                    m_best->Clone(offspring);
                    cout<<"E: "<<NumberOfFuncEvals<<"  ";m_best->Show();
                }
            
                this->UpdateReferencePoint(offspring);
                //this->UpdateSecondPopulation(offspring1);

                // update neighboring solutions, reference point, and second population
                this->UpdateNeighboringSolution(offspring, iPop);
		
            }
            
	        if(NumberOfFuncEvals>=MaxNumOfFuncEvals) break;
		}
      /*  cout<<"-------Gen "<<gen<<" ---------------"<<endl;
        for(iPop=0; iPop<5; iPop++)
        {
            CurrentPopulation[iPop].CurrentSolution.Show();
        }
        cout<<"------------------------------------"<<endl;*/
	    if(NumberOfFuncEvals>=MaxNumOfFuncEvals)
		{
			//printf("\n run %d %d nondominated solutions found by MOEAD \n", run_id, SecondPopulation.size());
            cout<<"Exit"<<endl;
			break;
		}
	}

	this->SaveSecondPopulation();
}

/*
 *
 */
bool CMOEAD::Exists(double fitness){
    
    int i;
    for(i=0;i<PopulationSize;i++){
        if(CurrentPopulation[i].CurrentSolution.m_fitness_value==fitness){
            return true;
        }
    }
    return false;
}

/*
 * Returns the best solution obtained.
 */
CIndividual * CMOEAD::GetBestSolution(){
    return m_best;
}


