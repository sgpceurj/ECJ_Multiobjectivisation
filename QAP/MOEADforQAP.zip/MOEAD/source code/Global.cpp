#include "Global.h"



int  seed = 3133;
long rnd_uni_init = - long(seed);

vector<double> ReferencePoint;
vector<double> ReferencePoint_Nadir;

int  NumberOfItems;
int  NumberOfELDComponents;
int  NumberOfObjectives;

char strFitnessType[1024];

int  run_id;
