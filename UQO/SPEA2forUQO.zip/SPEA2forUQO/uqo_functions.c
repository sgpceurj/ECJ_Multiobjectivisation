//
//  qap_functions.cpp
//  SPEA2
//
//  Created by Josu Ceberio Uribe on 23/12/15.
//  Copyright © 2015 University of the Basque Country. All rights reserved.
//

#include "spea2.h"
#include <stdio.h>
#include <assert.h>
#include <vector>
#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>

using std::ifstream;
using std::ofstream;
using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::stringstream;
using std::string;

uqo* read_instance(char * instancefile)
{
        //printf("Initializing... %d\n ",size);
    uqo* problem;
    problem=(uqo*)malloc(sizeof(uqo));
    
    FILE* fp = fopen(instancefile, "r");
    assert(fp != NULL);
    int size,i,j,val;
    fscanf(fp, "%d %d\n",&size,&val); /* read size */
    
    
  //  printf("Initializing... %d %d\n ",size,val);
    /* initialize qap structure */

    problem->size=size;
    problem->evaluations=0;
    problem->m_q=(int**)malloc(size*sizeof(int*));
    problem->m_v_vector=(int*)malloc(size*sizeof(int));
    for (i=0;i<size;i++){
        problem->m_q[i]=(int*)malloc(size*sizeof(int));
        fill_n(problem->m_q[i],size,0);
    }

    
    
    int q_ij;
    while(!feof(fp)){
        fscanf(fp,"%d %d %d\n",&i,&j,&q_ij);
        //printf("%d %d %d",i,j,q_ij);
        problem->m_q[i-1][j-1]=q_ij;
        problem->m_q[j-1][i-1]=q_ij;
    }
    fclose(fp);
    
    Calculate_v_vector(problem);
    
    //Calculate f0 constante landscape.
    problem->m_f0=f0_basic(problem);

    problem->best=create_ind(size, 3, problem->m_f0);
   // printMatrix(problem->m_q, size, size);
   // exit(1);
    return (problem);
}

/*
 * This function evaluates the individuals for the QAP problem as LOP.
 */
float evaluate(int * x, uqo * problem)
{
    float fitness=0;
    int i,j;
    for (i=0;i<problem->size;i++){
        if (x[i]==1){
            for (j=0;j<problem->size;j++){
                if (x[j]==1){
                    fitness=fitness+(problem->m_q[i][j]*x[i]*x[j]);
                }
            }
        }
    }
    return fitness;
}


void evaluate_optimized(ind * indiv,uqo * problem){
    
    float f=0,f2=0;
    int i,j;
    for (i=0;i<problem->size;i++){
        if (indiv->genes[i]==1){
            for (j=0;j<problem->size;j++){
                if (indiv->genes[j]==1)
                    f+=(problem->m_q[i][j]);
            }
            //f2+=(m_v_vector[i]*(1-(2*indiv->m_genes[i])));
            f2-=problem->m_v_vector[i];
        }
        else{
            f2+=problem->m_v_vector[i];
        }
    }
    f2=-0.25*f2;
    
    indiv->real_fitness=f;
    indiv->fitness=f;
    
    //indiv->m_fc[0]=m_f0;
    indiv->f[1]=f2;
    indiv->f[2]=f-f2-problem->m_f0;
    
}

/*
 * Given the Q matrix of parameters, it calculates the v vector used later in the decomposition.
 */
void Calculate_v_vector(uqo * problem){
    
    int i,j;
    std::fill_n(problem->m_v_vector,problem->size,0);
    for (i=0;i<problem->size;i++){
        for (j=0;j<problem->size;j++){
            problem->m_v_vector[i]+=(problem->m_q[i][j]+problem->m_q[j][i]);
        }
    }
}

/*
 * Calculates the fitness value corresponding to the zero component of the elementary landscape decomposition.
 * This component is constant, and thus, no solution for its calculation.
 */
float f0_basic(uqo * problem){
    float f0=0;
    int i,j;
    for (i=0;i<problem->size;i++){
        for (j=0;j<problem->size;j++){
            f0+=problem->m_q[i][j];
        }
        f0+=problem->m_q[i][i];
    }
    f0=0.25*f0;
    return f0;
}

/*
 * Calculates the fitness value corresponding to the first component of the elementary landscape decomposition.
 */
float f2_basic(int * x, uqo * problem){
    
    int i;
    float f2=0;
    for (i=0;i<problem->size;i++){
        f2+=problem->m_v_vector[i]*(1-(2*x[i]));
    }
    f2=-0.25*f2;
    return f2;
}

/*
 * Calculates the fitness value corresponding to the second component of the elementary landscape decomposition.
 */
float f4_basic(int * x,uqo * problem){
    
    int i,j;
    float f4=0;
    for (i=0;i<problem->size;i++){
        for (j=0;j<i;j++){
            f4+=problem->m_q[i][j]*(1-2*abs(x[i]-x[j]));
        }
        for (j=i+1;j<problem->size;j++){
            f4+=problem->m_q[i][j]*(1-2*abs(x[i]-x[j]));
        }
    }
    f4=0.25*f4;
    return f4;
}


void printMatrix(int** matrix, int length, int length2)
{
    int i,j;
    for (i=0;i<length;i++)
    {
        for (j=0;j<length2;j++)
        {
            printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }
}

void printArray(int* array, int size)/* Prints in standard output 'length' double elements of a given array. */
{
    for (int i=0;i<size;i++){
        printf(" %d,",array[i]);
    }
    printf("\n ");
}

/*
 * Generates a random binary solution of size 'n' in the given array.
 */
void GenerateRandomBinary(int * solution, long n)
{
    for (int i=0;i<n;i++){
        solution[i]=(((float)rand() / ((float)RAND_MAX))>=0.5);
    }
}

void initialize_pop(pop * population){
    int i;
    for (i=0;i<population->size;i++)
    {
        GenerateRandomBinary(population->ind_array[i]->genes,population->ind_array[i]->size);
    }
}

void evaluate_pop(pop * population, uqo * problem){
    int i;
    int i_best=-1;
    for (i=0;i<population->size;i++)
    {
        evaluate_optimized(population->ind_array[i], problem);
     
        //population->ind_array[i]->real_fitness=evaluate(population->ind_array[i]->genes, problem);
        
        //population->ind_array[i]->f[0]=problem->m_f0;
        //population->ind_array[i]->f[1]=f2_basic(population->ind_array[i]->genes, problem);
        //population->ind_array[i]->f[2]=f4_basic(population->ind_array[i]->genes, problem);
        //population->ind_array[i]->f[2]=population->ind_array[i]->real_fitness-problem->m_f0-population->ind_array[i]->f[1];
        
        problem->evaluations++;
        if ( (i_best==-1 && problem->best->real_fitness<population->ind_array[i]->real_fitness) || (i_best!=-1 && population->ind_array[i_best]->real_fitness<population->ind_array[i]->real_fitness)){
            i_best=i;
        }
    }
    if (i_best!=-1){
        memcpy(problem->best->f, population->ind_array[i_best]->f, sizeof(float)*3);
        problem->best->real_fitness=population->ind_array[i_best]->real_fitness;
        problem->best->fitness=population->ind_array[i_best]->fitness;
        problem->best->size=population->ind_array[i_best]->size;
        memcpy(problem->best->genes, population->ind_array[i_best]->genes, sizeof(int)*problem->best->size);
#ifdef VERBOSE
        printf("Best: %g  evals: %ld, f: %.5f, %.5f, %.5f\n ", problem->best->real_fitness, problem->evaluations, problem->best->f[0], problem->best->f[1], problem->best->f[2]);
#endif
    }
    
}

ind* binary_tournament (ind * indiv1, ind * indiv2){ //checks which of the individuals is fitter.
    
    if (dominates(indiv1,indiv2)){
//    if (indiv1->f[1]<indiv2->f[1] && indiv1->f[2]<indiv2->f[2]){
        return (indiv1);
    }
    if (dominates(indiv2,indiv1)){
//    if (indiv1->f[1]>indiv2->f[1] && indiv1->f[2]>indiv2->f[2]){
        return (indiv2);
    }
    if (indiv1->real_fitness>indiv2->real_fitness){
        return (indiv1);
    }
    if (indiv1->real_fitness<indiv2->real_fitness){
        return (indiv2);
    }
    if ((rand()/RAND_MAX) <= 0.5)
    {
        return(indiv1);
    }
    else
    {
        return(indiv2);
    }
}

void crossoverOPX (ind * parent1, ind * parent2, ind * child1, ind * child2 ){
    
    int i;
    int size=parent1->size;
    std::vector<int> non_used_parent1; int index_non_used1=0;
     std::vector<int> non_used_parent2; int index_non_used2=0;
    int element1,element2;
    for (i=0;i<size;i++) {
        element1=parent1->genes[i];
        element2=parent2->genes[i];
        if (EQUAL(element1, element2)==0){
            child1->genes[i]=-1;
            child2->genes[i]=-1;
            non_used_parent1.push_back(element1);
            non_used_parent2.push_back(element2);
        }
        else{
            child1->genes[i]=element1;
            child2->genes[i]=element2;
        }
    }
    
    int crossover_point= (rand()% (size-2));
    memcpy(child1->genes, parent1->genes, sizeof(int)*(crossover_point+1));
    memcpy(child2->genes, parent2->genes, sizeof(int)*(crossover_point+1));
    
    for (i=0;i<=crossover_point;i++){
        remove(&non_used_parent2, parent1->genes[i]);
        remove(&non_used_parent1, parent2->genes[i]);
    }
    
    for (i=crossover_point+1;i<size;i++){
        if (child1->genes[i]==-1){
            child1->genes[i]=non_used_parent2.at(index_non_used2);
            index_non_used2++;
        }
        if (child2->genes[i]==-1){
            child2->genes[i]=non_used_parent1.at(index_non_used1);
            index_non_used1++;
        }
    }
    non_used_parent1.clear();
    non_used_parent2.clear();
}


/*
 * Crossover operator. ULX
 */
void Crossover_ULX (ind * parent1, ind * parent2,ind * child1, ind * child2 ){
    
    int i;
    for (i=0;i<parent1->size;i++) {
        if (parent1->genes[i]!=parent2->genes[i]){
            child1->genes[i]=(((float)rand()/(float)RAND_MAX)<0.5);
            child2->genes[i]=(((float)rand()/(float)RAND_MAX)<0.5);
        }
        else{
            child1->genes[i]=parent1->genes[i];
            child2->genes[i]=parent1->genes[i];
        }
    }
}

/*
 * Crossover operator. OPX
 */
void Crossover_OPX (ind * parent1, ind * parent2, ind * child1, ind * child2 ){
    
    int i;
    int crossover_point= (rand()% (parent1->size-1));
    memcpy(child1->genes, parent1->genes, sizeof(int)*(crossover_point));
    memcpy(child2->genes, parent2->genes, sizeof(int)*(crossover_point));
    
    for (i=crossover_point;i<parent1->size;i++){
        child1->genes[i]=parent2->genes[i];
        child2->genes[i]=parent1->genes[i];
    }
}


void mutateSwap(int * genes, int size){
    int i=rand()% size;
    int j=rand()% size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}


/*
 * Mutates the individual applying the interchange mutation operator.
 */
void Mutate_Interchange(int * genes, int size){
    int i=rand()% size;
    int j=rand()% size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}

/*
 * Mutates the individual applying the bit-flip operator
 */
void Mutate_BitFlip(int * genes, int size){
    int i=rand()% size;
    genes[i]=!genes[i];
}

/*
 * Mutates the individual applying the reverse mutation operator.
 */
void Mutate_Reverse(int * genes, int size){
    
    for (int i=0;i<size;i++)
    {
        genes[i]=!genes[i];
    }
}


bool remove(std::vector<int> * v, int element){
    
    for (int i=0;i<v->size();i++){
        if (element==v->at(i)){
            v->erase(v->begin()+i);
            return true;
        }
    }
    return false;
}

