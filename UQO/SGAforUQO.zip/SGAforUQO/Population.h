//
//  Population.h
//  RankingEDAsCEC
//
//  Created by Josu Ceberio Uribe on 11/19/13.
//  Copyright (c) 2013 Josu Ceberio Uribe. All rights reserved.
//

#ifndef _POPULATION_
#define _POPULATION_


#include <algorithm>
#include <string.h>
#include <sstream>
#include <stdlib.h>
#include <stdio.h>
#include <fstream>
#include <iostream>
#include <vector>
#include "Individual.h"
#include "UQO.hpp"

using std::istream;
using std::ostream;
using std::stringstream;
using std::string;
using namespace std;
typedef struct lists
{
    int index;
    struct lists *parent;
    struct lists *child;
} list;
class CPopulation
{
    
public:
    
    struct Better{
        bool operator()(CIndividual * a, CIndividual * b) const{
                return a->m_value>b->m_value;
        }
    } Better;
    
    struct BetterRank{
        bool operator()(CIndividual * a, CIndividual * b) const{
            return a->m_rank<b->m_rank;
        }
    } BetterRank;
    
    /*
     * Vector of individuals that constitute the population.
     */
    vector<CIndividual *> m_individuals;

    vector< vector<int> > m_S;
    vector< vector<int> > m_F;
    vector<CIndividual *> m_clone;
    int * m_n;
    int * m_marks;
    
    /*
     * Size of the population
     */
    int m_pop_size;
    
    /*
     * Size of the individuals
     */
    int m_problem_size;
    
	/*
     * The constructor. It creates an empty list.
     */
    CPopulation(int pop_size, int individual_size);
    
	/*
     * The destructor.
     */
	virtual ~CPopulation();
    

    /*
     * Function to set an individual in a specific position of the population
     */
    void SetToPopulation(int * genes, int index, int fitness, float * fc);
    
    /*
     * Sorts the individuals in the population in ascending order of the fitness value.
     * returns true if the best solution was outperformed.
     */
    bool SortPopulation(CIndividual * best);
    
    /*
     * Sorts the individuals in the population in descending order of the rank value.
     */
    bool SortPopulationWithRank();
    
    /*
     *  Calculates the paretos in the population
     */
    bool CalculateParetos( bool fc1_constant, int num_samples);
        
    /*
     *  Performs the nondominated sorting of the NSGA-II proposed by debt et al, and adapted by J. Ceberio to truncate the last pareto.
     */
    bool Fast_NonDominatedSorting_Adapted(CIndividual * best);

 
    /*
     * Checks whether there exists a solution in the population with the given fitness.
     */
    bool Exists(int i, int fitness);
    
    /*
     * Prints the current population.
     */
    void Print(int samples);
    
	/*
	 * Determines if the individuals in the population are equal.
	 */
	bool Same(int size);
    
    /*
     * Calculates the average fitness of the first 'size' solutions in the population
     */
    float AverageFitnessPopulation(int size);
    
    /*
     * Returns the best individual of the population.
     */
    CIndividual * BestIndividual();
    
    /*
     * Calculates the average distance of the first 'size' solutions in the population
     */
    float AverageDistancePopulation(int size);
    
    
private:
    
};

#endif


