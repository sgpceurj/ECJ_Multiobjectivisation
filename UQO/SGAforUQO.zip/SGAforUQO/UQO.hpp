//
//  UQO.hpp
//  NSGA2forUQO
//
//  Created by Josu Ceberio Uribe on 16/02/17.
//  Copyright © 2017 University of the Basque Country. All rights reserved.
//

#ifndef UQO_hpp
#define UQO_hpp

#include "Tools.h"
#include <stdlib.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string.h>
#include <stdio.h>

using std::ifstream;
using std::ofstream;
using std::istream;
using std::ostream;
using namespace std;
using std::cerr;
using std::cout;
using std::endl;
using std::stringstream;
using std::string;

class UQO
{
    
public:
    
    /*
     * The matrix of values of the instance.
     */
    int ** m_q;
    
    /*
     * Array of v vectors.
     */
    int * m_v_vector;
    
    /*
     * The number of jobs of the problem.
     */
    int m_size;
    
    /*
     * f0 landscape (it is constant).
     */
    float m_f0;
    
    /*
     * The constructor. It initializes a UQO from a file.
     */
    UQO();
    
    /*
     * The destructor.
     */
    virtual ~UQO();
    
    /*
     * Read UQO instance from file.
     */
    int Read(char * instancefile);
    
    /*
     * This function evaluates the individuals for the UQO problem.
     */
    float Evaluate(int * solution);
    
    /*
     * Returns the size of the problem.
     */
    int GetProblemSize();
    
    void Eval_Complete(CIndividual * indiv);
    /*
     * Calculates the fitness value corresponding to the zero component of the elementary landscape decomposition.
     * This component is constant, and thus, no solution for its calculation.
     */
    float f0_basic();
    
    /* 
     * Calculates the fitness value corresponding to the FIRST and SECOND component of the elementary landscape decomposition. 
     * The codes are NOT optimized.
     */
    float f2_basic(int * solution);
    float f4_basic(int * solution);
    
    /*
     * Given the Q matrix of parameters, it calculates the v vector used later in the decomposition.
     */
    void Calculate_v_vector();
    
    
private:
    
};

#endif /* UQO_hpp */
