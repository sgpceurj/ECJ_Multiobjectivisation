/*
 *  Variables.h
 *  DiscreteEDA
 *
 *  Created by Josu Ceberio Uribe on 11/21/11.
 *  Copyright 2011 University of the Basque Country. All rights reserved.
 *
 */

//Integer maximum value
#define MAX_INTEGER 2147483647

//Integer minimum value
#define MIN_INTEGER -2147483647

//Long integer maximum value
#define MAX_LONG_INTEGER 429496729500000

//Long integer maximum value
#define MIN_LONG_INTEGER -42949672950000

//Max operation.
#define MAX(A,B) ( (A > B) ? A : B)

//Min operation.
#define MIN(A,B) ( (A < B) ? A : B)

//Equal operation.
#define EQUAL(A,B) ( (A == B) ? 1 : 0)

//Not equal operation.
#define NON_EQUAL(A,B) ( (A != B) ? 1 : 0)

//Print trace
//#define VERBOSE 1

//Activates the multiobjective approach of the genetic algorithm.
// commented <- SGA
// 1 <- NSGA2 with adapted pareto selection.
// 2 <- NSGA2 with the original pareto selection.
#define EXEC_NSGA2 2

//Prints every 10 iterations the average distance between the solutions in the population, and the average fitness of the individuals in the population
//#define PRINT_CONVERGENCE_DATA

// 0 <- Interchange mutation
// 1 <- Bit-flip mutation
// 2 <- Reverse mutation
#define MUTATION_TYPE 1

// 0 <- One-Point-Crossover
// 1 <- Uniform-Crossover
#define CROSSOVER 1

#define KALIMERO 1 //Activated when running on kalimero.

