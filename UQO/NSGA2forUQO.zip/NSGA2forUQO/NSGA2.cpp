//
//  NSGA2.cpp
//  NSGA2forQAP
//
//  Created by Josu Ceberio Uribe on 02/07/14.
//  Copyright (c) 2014 Josu Ceberio Uribe. All rights reserved.
//

#include "NSGA2.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "DebtCode.hpp"
#include "Population.h"


/*
 * The constructor.
 */
NSGA2::NSGA2(UQO * problem, int problem_size, long int max_evaluations)
{
    // cout<<"Constructing NSGA2..."<<endl;
    //1. standard initializations
    m_problem=problem;
    m_problem_size=problem_size;
    m_max_evaluations=max_evaluations;
    m_evaluations=0;
    m_convergence_evaluations=0;
    m_best= new CIndividual(problem_size);
    m_pop_size=m_problem_size*8;

    m_sel_size=m_pop_size;
    m_offspring_size= m_pop_size;
    //new set of parameters for the paper
    /*m_pop_size=m_problem_size;
    m_sel_size=m_pop_size;
    m_offspring_size= m_problem_size/2;
    if (m_sel_size%2!=0){
        m_sel_size++;
    }
    if (m_offspring_size%2!=0){
        m_offspring_size++;
    }
    cout<<"Sel size: "<<m_sel_size<<" off size: "<<m_offspring_size<<endl;*/
    m_parent_pop = new CPopulation(m_pop_size, m_problem_size);
    for (int i=0;i<m_pop_size;i++)
    {
        m_parent_pop->m_individuals[i]->m_fc[0]=problem->m_f0;
    }
    m_child_pop = new CPopulation(m_offspring_size,m_problem_size);
    for (int i=0;i<m_offspring_size;i++)
    {
        m_child_pop->m_individuals[i]->m_fc[0]=problem->m_f0;
    }
    m_mixed_pop = new CPopulation(m_pop_size+m_offspring_size, m_problem_size);
    for (int i=0;i<m_pop_size+m_offspring_size;i++)
    {
        m_mixed_pop->m_individuals[i]->m_fc[0]=problem->m_f0;
    }
    m_selection_a1 = new int[m_pop_size];
    m_selection_a2 = new int[m_pop_size];
}

/*
 * The destructor. It frees the memory allocated..
 */
NSGA2::~NSGA2()
{
  //  cout<<"Destructing NSGA2..."<<endl;
//    delete m_best; //it is included in the population.
    delete m_parent_pop;
    delete m_child_pop;
    delete m_mixed_pop;
    
    
    delete [] m_selection_a1;
    delete [] m_selection_a2;
}
/*
 * Routine for tournament selection, it creates a new_pop from old_pop by performing tournament selection and the crossover
 */
void NSGA2::Selection (CPopulation *old_pop, CPopulation *new_pop){

    int temp;
    int i;
    int r;
    CIndividual *parent1, *parent2;

    for (i=0; i<old_pop->m_pop_size; i++)
    {
        m_selection_a1[i] = i;// m_selection_a2[i] = i;
    }
   for (i=0; i<old_pop->m_pop_size; i++)
    {
        r = i+(rand()%(old_pop->m_pop_size-i));
        temp = m_selection_a1[r];
        m_selection_a1[r] = m_selection_a1[i];
        m_selection_a1[i] = temp;
      /*   r = i+(rand()%(m_pop_size-i));
        temp = m_selection_a2[r];
        m_selection_a2[r] = m_selection_a2[i];
        m_selection_a2[i] = temp;*/
    }

    for (i=0; i<new_pop->m_pop_size; i+=2)
    {
        parent1 = Tournament (old_pop->m_individuals[m_selection_a1[i]], old_pop->m_individuals[m_selection_a1[i+1]]);
        parent2 = Tournament (old_pop->m_individuals[m_selection_a1[i+2]], old_pop->m_individuals[m_selection_a1[i+3]]);
        if (CROSSOVER==0)
            Crossover_OPX (parent1, parent2, new_pop->m_individuals[i], new_pop->m_individuals[i+1]);
        else
            Crossover_ULX (parent1, parent2, new_pop->m_individuals[i], new_pop->m_individuals[i+1]);

        new_pop->SetToPopulation(parent1->m_genes, i, parent1->m_value, parent1->m_fc);
        new_pop->SetToPopulation(parent2->m_genes, i+1, parent2->m_value, parent2->m_fc);

        //parent1 = Tournament (old_pop->m_individuals[m_selection_a2[i]], old_pop->m_individuals[m_selection_a2[i+1]]);
        //parent2 = Tournament (old_pop->m_individuals[m_selection_a2[i+2]], old_pop->m_individuals[m_selection_a2[i+3]]);
        //Crossover_OPX (parent1, parent2, new_pop->m_individuals[i+2], new_pop->m_individuals[i+3]);
    }
}
int Contains(vector<int>v, int element){
    
    for (int i=0;i<v.size();i++)
        if (element==v[i])
            return i;
    return -1;
}

bool Remove(vector<int> * v, int element){

    for (int i=0;i<v->size();i++){
        if (element==v->at(i)){
            v->erase(v->begin()+i);
            return true;
        }
    }
    return false;
}

/*
 * Crossover operator. ULX
 */
void NSGA2::Crossover_ULX (CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2 ){
    
    int i;
    for (i=0;i<m_problem_size;i++) {
        if (parent1->m_genes[i]!=parent2->m_genes[i]){
            child1->m_genes[i]=(((float)rand()/(float)RAND_MAX)<0.5);
            child2->m_genes[i]=(((float)rand()/(float)RAND_MAX)<0.5);
        }
        else{
            child1->m_genes[i]=parent1->m_genes[i];
            child2->m_genes[i]=parent1->m_genes[i];
        }
    }
}

/*
 * Crossover operator. OPX
 */
inline void NSGA2::Crossover_OPX (CIndividual * parent1, CIndividual * parent2,CIndividual * child1, CIndividual * child2 ){

    int i;
    int crossover_point= (rand()% (m_problem_size-1));
    memcpy(child1->m_genes, parent1->m_genes, sizeof(int)*(crossover_point));
    memcpy(child2->m_genes, parent2->m_genes, sizeof(int)*(crossover_point));
    
    for (i=crossover_point;i<m_problem_size;i++){
        child1->m_genes[i]=parent2->m_genes[i];
        child2->m_genes[i]=parent1->m_genes[i];
    }
}

/*
 * Tournament.
 */
inline CIndividual * NSGA2::Tournament (CIndividual * ind1, CIndividual * ind2){
    
#ifdef EXEC_NSGA2
    int dominance=Dominates_optimized(ind1,ind2);
    if (dominance==0){
        //    if (ind1->m_fc2<ind2->m_fc2 && ind1->m_fc3<ind2->m_fc3){
        return (ind1);
    }
    if (dominance==1){
        //if (ind1->m_fc2>ind2->m_fc2 && ind1->m_fc3>ind2->m_fc3){
        return (ind2);
    }
#endif
    if (ind1->m_value>ind2->m_value){
        return (ind1);
    }
    if (ind1->m_value<ind2->m_value){
        return (ind2);
    }
    if ((rand()/RAND_MAX) <= 0.5)
    {
        return(ind1);
    }
    else
    {
        return(ind2);
    }
}

/*
 * Evaluates the individuals in the population.
 */
void NSGA2::Evaluate_Pop(CPopulation * population){
    
    int i;
    CIndividual *g;
    for (i=0;i<population->m_pop_size;i++){
        g=population->m_individuals[i];
        #ifndef EXEC_NSGA2
            g->m_value=m_problem->Evaluate(g->m_genes);
        #else
            m_problem->Eval_Complete(g);
        #endif
    }
    m_evaluations=m_evaluations+population->m_pop_size;
}

/*
 * Mutates the individual applying the interchange mutation operator.
 */
void NSGA2::Mutate_Interchange(int * genes){
    int i=rand()% m_problem_size;
    int j=rand()% m_problem_size;
    int aux=genes[i];
    genes[i]=genes[j];
    genes[j]=aux;
}

/*
 * Mutates the individual applying the bit-flip operator
 */
void NSGA2::Mutate_BitFlip(int * genes){
    int i=rand()% m_problem_size;
    genes[i]=!genes[i];
}

/*
 * Mutates the individual applying the reverse mutation operator.
 */
void NSGA2::Mutate_Reverse(int * genes){
    
    for (int i=0;i<m_problem_size;i++)
    {
        genes[i]=!genes[i];
    }
}

/*
 * Mutates the individuals in the population.
 */
void NSGA2::Mutate_Pop(CPopulation * population){
    int i;
    CIndividual *g;
    for (i=0;i<population->m_pop_size;i++){
        g=population->m_individuals[i];
        if (MUTATION_TYPE==0)
            Mutate_Interchange(g->m_genes);
        else if (MUTATION_TYPE==1)
            Mutate_BitFlip(g->m_genes);
        else
            Mutate_Reverse(g->m_genes);
    }
}

/*
 * Routine to merge two populations into one
 */
void NSGA2::Merge(CPopulation *pop1, CPopulation *pop2, CPopulation *pop3)
{
    int i, k;
    for (i=0; i<pop1->m_pop_size; i++)
    {
        Copy_Ind(pop1->m_individuals[i], pop3->m_individuals[i]);
    }
    for (i=0, k=pop1->m_pop_size; i<pop2->m_pop_size; i++, k++)
    {
        Copy_Ind(pop2->m_individuals[i], pop3->m_individuals[k]);
    }
    return;
}

/*
 * Running function
 */
int NSGA2::Run(char * instance_filename){
#ifdef VERBOSE
     cout<<"Running NSGA2..."<<endl;
#endif
    /////////////////////////////////////////////////
    //1. Initialize population randomly and evaluate
    /////////////////////////////////////////////////
    
    
    int i;
    CIndividual * g;
    for(i=0;i<m_pop_size;i++)
    {
        g=m_parent_pop->m_individuals[i];
        //Create random individual
        GenerateRandomBinary(g->m_genes,m_problem_size);
        #ifndef EXEC_NSGA2
            g->m_value=m_problem->Evaluate(g->m_genes);
        #else
            m_problem->Eval_Complete(g);
        #endif
        m_evaluations++;
        //cout<<"f: "<<f<<"  f2: "<<fc[1]<<"  f4: "<<fc[2]<<" f0+f2+f4: "<<fc[0]+fc[1]+fc[2]<<endl;
    }
   
    m_best->m_value=MIN_INTEGER;

    /////////////////////////////////////////////////
    //2. Non-dominated fast sorting
    /////////////////////////////////////////////////
    //m_parent_pop->Print(10);
#ifdef EXEC_NSGA2
    if (EXEC_NSGA2==1)
        m_parent_pop->Fast_NonDominatedSorting_Adapted(m_best);
    else { //if (EXEC_NSGA2==2){
        assign_rank_and_crowding_distance(m_parent_pop,m_best);
        m_parent_pop->SortPopulationWithRank();
    }
#else
        m_parent_pop->SortPopulation(m_best);
#endif
   // cout<<"-------"<<endl;
    //m_parent_pop->Print(10); exit(1);
    
    /////////////////////////////////////
    //3. Start the iterative process
    /////////////////////////////////////
    bool improved=false;
    int iteration=0;

    while (m_evaluations<m_max_evaluations){
        
        Selection(m_parent_pop, m_child_pop);
        Mutate_Pop(m_child_pop);
        Evaluate_Pop(m_child_pop);
        Merge(m_parent_pop,m_child_pop,m_mixed_pop);
        //exit(1);
       #ifdef EXEC_NSGA2
        if (EXEC_NSGA2 == 1)
            improved=m_mixed_pop->Fast_NonDominatedSorting_Adapted(m_best);
        else //if (MODE==2){
            improved= Fast_NonDominatedSorting_Original(m_mixed_pop, m_parent_pop, m_best);
        //}
        #else
            improved=m_mixed_pop->SortPopulation(m_best);
        
        #endif

 #ifndef EXEC_NSGA2
            for (i=0; i<m_pop_size; i++)
                Copy_Ind(m_mixed_pop->m_individuals[i], m_parent_pop->m_individuals[i]);
#endif
#ifdef EXEC_NSGA2
        if (EXEC_NSGA2==1){
            for (i=0; i<m_pop_size; i++)
                Copy_Ind(m_mixed_pop->m_individuals[i], m_parent_pop->m_individuals[i]);
        }
#endif
    
#ifdef VERBOSE
        if (improved)
            //cout<<"B: "<<m_best->m_value<<" E: "<<m_evaluations<<endl;
        printf("%.1f, %d, [%.1f,%.1f,%.1f]\n",m_best->m_value,m_evaluations,m_best->m_fc[0],m_best->m_fc[1],m_best->m_fc[2]);

    
#endif
         //m_parent_pop->Print(10); exit(1);
        iteration++;
    }
    return m_best->m_value;
}

/*
 * Returns the fitness of the best solution obtained.
 */
int NSGA2::GetBestSolutionFitness(){
    return m_best->m_value;
}

/*
 * Returns the best solution obtained.
 */
CIndividual * NSGA2::GetBestSolution(){
    return m_best;
}
