//
//  UQO.cpp
//  NSGA2forUQO
//
//  Created by Josu Ceberio Uribe on 16/02/17.
//  Copyright © 2017 University of the Basque Country. All rights reserved.
//

#include "UQO.hpp"
#include "Variables.h"

/*
 *Class constructor.
 */
UQO::UQO()
{
    
}

/*
 * Class destructor.
 */
UQO::~UQO()
{
    for (int i=0;i<m_size;i++)
    {
        delete [] m_q[i];
    }
    delete [] m_v_vector;
}



int UQO::Read(char * instancefile)
{
    
    //printf("Initializing... %d\n ",size);
    
    FILE* fp = fopen(instancefile, "r");
    
    int z,i,j,val;
    fscanf(fp, "%d %d\n",&m_size,&val); /* read size */
    printf("%d\n",m_size);
    m_q = new int*[m_size];

    for (z=0;z<m_size;z++)
    {
        m_q[z]= new int[m_size];
        fill_n(m_q[z], m_size,0);
    }
    
    int q_ij;
    while(!feof(fp)){
        fscanf(fp," %d %d %d\n",&i,&j,&q_ij);
        //printf("%d %d %d",i,j,q_ij);
        m_q[i-1][j-1]=q_ij;
        m_q[j-1][i-1]=q_ij;
    }
    fclose(fp);
    
    //Calculate v vector
    Calculate_v_vector();
    //PrintArray(m_v_vector, m_size, "v vector: ");
    
    //Calculate f0 constante landscape.
    m_f0=f0_basic();
    //cout<<"f0: "<<m_f0<<endl;
    
    return (m_size);
}

/*
 * This function evaluates the individuals for the UQO problem.
 */
float UQO::Evaluate(int * x)
{
    float fitness=0;
    int i,j;
    for (i=0;i<m_size;i++){
        if (x[i]==1){
            for (j=0;j<m_size;j++){
                if (x[j]==1)
                    fitness+=(m_q[i][j]);
            }
        }
    }
    return fitness;
}

/*
 * Returns the size of the problem.
 */
int UQO::GetProblemSize()
{
    return m_size;
}

/*
 * Given the Q matrix of parameters, it calculates the v vector used later in the decomposition.
 */
void UQO::Calculate_v_vector(){
    m_v_vector= new int[m_size];
    int i,j;
    std::fill_n(m_v_vector,m_size,0);
    for (i=0;i<m_size;i++){
        for (j=0;j<m_size;j++){
            m_v_vector[i]+=(m_q[i][j]+m_q[j][i]);
        }
    }
}

void UQO::Eval_Complete(CIndividual * indiv){
    float f=0,f2=0;
    int i,j;
    for (i=0;i<m_size;i++){
        if (indiv->m_genes[i]==1){
            for (j=0;j<m_size;j++){
                if (indiv->m_genes[j]==1)
                    f+=(m_q[i][j]);
            }
            //f2+=(m_v_vector[i]*(1-(2*indiv->m_genes[i])));
            f2-=m_v_vector[i];
        }
        else{
            f2+=m_v_vector[i];
        }
    }
    f2=-0.25*f2;
    
    indiv->m_value=f;
    
    //indiv->m_fc[0]=m_f0;
    indiv->m_fc[1]=f2;
    indiv->m_fc[2]=f-f2-m_f0;
}

/*
 * Calculates the fitness value corresponding to the zero component of the elementary landscape decomposition.
 * This component is constant, and thus, no solution for its calculation.
 */
float UQO::f0_basic(){
    float f0=0;
    int i,j;
    for (i=0;i<m_size;i++){
        for (j=0;j<m_size;j++){
            f0+=m_q[i][j];
        }
        f0+=m_q[i][i];
    }
    f0=0.25*f0;
    return f0;
}

/*
 * Calculates the fitness value corresponding to the first component of the elementary landscape decomposition.
 */
float UQO::f2_basic(int * x){
    
    int i;
    float f2=0;
    for (i=0;i<m_size;i++){
        f2+=(m_v_vector[i]*(1-(2*x[i])));
    }
    f2=-0.25*f2;
    return f2;
}

/*
 * Calculates the fitness value corresponding to the second component of the elementary landscape decomposition.
 */
float UQO::f4_basic(int * x){
    
    int i,j;
    float f4=0;
    for (i=0;i<m_size;i++){
        for (j=0;j<i;j++){
            f4+=m_q[i][j]*(1-2*abs(x[i]-x[j]));
        }
        for (j=i+1;j<m_size;j++){
            f4+=m_q[i][j]*(1-2*abs(x[i]-x[j]));
        }
    }
    f4=0.25*f4;
    return f4;
}

